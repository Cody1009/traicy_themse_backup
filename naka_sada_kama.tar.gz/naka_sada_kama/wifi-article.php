<?php 
# APIを叩いてマスタデータを取得
$target_url = "http://api.kakaku.com/mobile_data/world-wifi/api/searchXml/ver2/master/?key=NRWMVEUQG9NN335KVMGGACZE8BCT9C4V";
//$xml = simplexml_load_file($target_url);
?>

<?php
function getFoo($input){
	if($input == "フォートラベル GLOBAL WiFi")	return "フォートラベル";
	return $input;
}
?>
<?php
#{{{
$country = array(
	"アメリカ" => 6,
	"韓国" => 94,
	"中国" => 102,
	"カナダ" => 23,
	"インド" => 91,
	"インドネシア（バリ島以外の全域）" => 92,
	"インドネシア（バリ島）" => 93,
	"タイ" => 99,
	"台湾" => 100,
	"フィリピン" => 109,
	"ベトナム" => 112,
	"マレーシア（マレー半島主要都市）" => 115,
	"マレーシア（ボルネオ島及び全域）" => 116,
	"イギリス" => 144,
	"イタリア" => 149,
	"オーストラリア" => 79,
	"スペイン" => 170,
	"ドイツ" => 178,
	"フランス" => 184,
	"香港" => 113,
	"ハワイ" => 61,
	"グアム" => 29,
	"選択肢なし" => 0,
);
#}}}
?>

<?php
// エラーを画面に表示(1を0にすると画面上にはエラーは出ない)
//ini_set('display_errors',1);
?>

<?php
#$country_id = (is_null($values) || count($values) == 0) ? 0 : max($values);
$country_id = (int)get_post_meta($post->ID, 'wifi_country_id', true);
if($country_id != 0) :
?>

<?php
$base_url = "http://api.kakaku.com/mobile_data/world-wifi/api/searchXml/ver2/search/?key=NRWMVEUQG9NN335KVMGGACZE8BCT9C4V&";
$param = array(
	"country" => $country_id,
	"use_days" => 1,
	"compensationType" => 7001,
	"receipt" => 1,
	"return" => 1
);
$url = $base_url . http_build_query($param);
$file = file_get_contents($url);
$xml = preg_replace('/&(?=[a-z_0-9]+=)/m','&amp;',$file);
$xmlData = simplexml_load_string($xml);
$countryName = $xmlData -> parameter -> areaName;
?>
	<!-- コンテンツ -->


<span class="countryTitle"><?php echo $countryName ?>のWifi価格比較</span>

<div class="hide_u600 wificompeL">
	<div class="container">
<?php foreach($xmlData -> serviceList -> service as $itemValue) : ?>
		<a href = "<?php echo $itemValue -> detailUrl; ?>">
			<div class="item">
				<div class="logo"><img src="<?php echo $itemValue -> serviceLogo; ?>" class="imageLogo"></div>
				<div class="information">
					<p class="comTitle"><?php echo $itemValue -> serviceName; ?></p>
<?php if((string)($itemValue -> kakakuCampaignFlg) === "1") : ?>
					<p class="kakakuTitle">価格.com限定価格</p>
<?php else : ?>
					<p class="kakakuTitle"><br></p>
<?php endif; ?>
					<p class = "lineSpeed">回線速度&nbsp;:&nbsp;<?php echo $itemValue -> lineType; ?></p>
					<p class = "lineCapasity"><?php echo $itemValue -> lineComment; ?></p>
					<p class = "lineCost"><span style="font-size:10px">１日あたり</span>&yen;<?php echo $itemValue -> rentalFee; ?></p>
				</div>
			</div>
		</a>
<?php endforeach; ?>
	</div>
</div>


<div class="hide_o600 wificompeS">
	<div class="container">
<?php foreach($xmlData -> serviceList -> service as $itemValue) : ?>
		<a href = "<?php echo $itemValue -> detailUrl; ?>">
			<div class="item">
				<div class="logo"><img src="<?php echo $itemValue -> serviceLogo; ?>" class="imageLogo"></div>
				<div class="information">
					<p class="comTitle"><?php echo getFoo($itemValue -> serviceName); ?></p>
<?php if((string)($itemValue -> kakakuCampaignFlg) === "1") : ?>
					<p class="kakakuTitle">価格.com限定価格</p>
<?php else : ?>
					<p class="kakakuTitle"><br></p>
<?php endif; ?>
					<p class = "lineSpeed">回線速度&nbsp;:&nbsp;<?php echo $itemValue -> lineType; ?></p>
					<p class = "lineCapasity"><?php echo $itemValue -> lineComment; ?></p>
					<p class = "lineCost"><span style="font-size:10px">１日あたり</span>&yen;<?php echo $itemValue -> rentalFee; ?></p>
				</div>
			</div>
		</a>
<?php endforeach; ?>
	</div> <!-- container -->
</div> <!-- wificomepS -->

<?php endif; ?>


<?php global $myAmp ?>

<html ⚡>
    <head>

<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="shortcut icon" href="https://www.traicy.com/images/icons/favicon.ico" />

<!-- AMP metaタグ 参考：　https://q-az.net/amp-wordpress-without-plugin/　-->
<meta charset="<?php bloginfo( 'charset' ); ?>" />

    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">

<!-- AMP canonical 参考：　https://q-az.net/amp-wordpress-without-plugin/　-->
<?php $canonical_url = get_permalink(); ?>
    <link rel="canonical" href="<?php echo $canonical_url; ?>" />

<!-- AMP Boilerplate Code -->
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>

<!-- スタイルシート読み込み -->
<style amp-custom>
<?php 
$css_dir = get_stylesheet_directory_uri() . "/css/";
$css_text = "";
$css_file_names = ["style.css", "single.css", "header.css", "footer.css", "page.css"];
foreach ($css_file_names as $name) {
  $css_text .= file_get_contents($css_dir . $name);
}

// ampで禁止されている要素をリスト
$selectors = array("\@viewport", "\@-ms-viewport", "\.share_box", "\@-ms-viewport", "\.wp_social_bookmarking", "\.social-icon", ".result");

// 禁止されている要素を削除
$css_text = preg_replace("/\!important/", "", $css_text);
foreach($selectors as $selector):
  $css_text = preg_replace("/^.*?{$selector}.*?{(\n|\w|.)*?}/m", "", $css_text);
endforeach;
// コメントを削除
$css_text = preg_replace("/\/\*(\n|.)*?\*\//", "", $css_text);

// 邪魔なので削除
//$css_text = preg_replace("color: #000;", "", $css_text);

// cssで現れるdivを削除
//$css_text = preg_replace("/div(.*?){/", "\\1", $css_text);

echo $css_text;
?>
/* amp  st */
amp-ad {
  margin-top: 10px auto 0;
  text-align: center;
}
a>span {
  color: #006835;
  text-decoration: underline;
}

nav#site-navigation {
  text-align: left;
  padding-left: 10px;
  height: 75px;
	border: 1px solid #e5e5e5;
}

span.onlyCategory a {
	color: white;
}
.tag_box a {
	color: white;
	display: inline-block;
	margin: 5px 0;
}

.header_set {
  /* 中央寄せ */
  margin: 6px -webkit-calc((100% - 295px) / 2) 0;
  height: 49px;
}
nav#site-navigation .header_logo{
  margin: 0px;
  width: 80px;
  margin-right: 15px;
  float: left;
}
.amp_traicy_desc {
  display: inline-block;
  float: left;
  color: black;
  font-size: 12px;
  height: 40px;
  width: 200px;
  padding-top: 10px;
  margin: 0;
}
.clear {
  width: 0;
  height: 0;
  clear: both;
}
/* amp end */
</style>

<!-- AMP Json -->
<!-- "headline": "<?php //bloginfo('description'); ?>"-->
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "NewsArticle",
  "headline": "<?php the_title(); ?>",
  "mainEntityOfPage":{
    "@type":"WebPage",
    "@id":"<?php the_permalink(); ?>"
  },
  "image": {
    "@type": "ImageObject",
    "url": "<?php the_post_thumbnail_url('medium'); ?>",
    "height": 600,
    "width": 400
  },
  "datePublished":"<?php echo get_the_date('c'); ?>",
  "dateModified": "<?php the_modified_date('c'); ?>", 
  "author": {
    "@type": "Person",
    "name": "<?php $author=get_the_author(); echo $author==''?'Traicy編集部':$author; ?>"
  },
   "publisher": {
    "@type": "Organization",
    "name": "<?php wp_title(); ?>",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.traicy.com/images/logo.gif",
      "width": 273
    }
  },
  "description": "<?php bloginfo('description'); ?>"
}
</script>
<!-- AMP Json -->


<!-- AMP ライブラリ -->
<script async src="https://cdn.ampproject.org/v0.js"></script>

<!-- AMP ライブラリ -->

<!-- AMP クローラー対策 -->
<link rel="amphtml" href="<?php echo $canonical_url.'?amp=1'; ?>">
<!-- AMP クローラー対策 -->

<!-- AMP用の広告スクリプト -->
<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>
<!-- AMP用の広告スクリプト -->

<!-- アナリティクス用のスクリプト -->
<script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script>
<!-- アナリティクス用のスクリプト -->
</head>

<body <?php body_class(); ?>>
    <div id="header" class="hide_u600">
			<div class="header_text">
				<a href="/"><div>traicy</div></a>
				<a href="http://www.hotelers.jp/"><div>Hotelers</div></a>
				<a href="http://www.guesthousetoday.jp/"><div>GuesthouseToday</div></a>
				<a href="http://www.extrain.info/"><div>EX-TRAIN</div></a>
				<a href="http://www.traicy.com.tw/"><div>Traicy Taiwan</div></a>
			</div>
			<div class="social-icon">
				<a class="side-twitter" href="https://twitter.com/traicycom" target="_blank"><span class="icon-twitter"></span></a>
				<a class="side-facebook" href="https://www.facebook.com/traicycom" target="_blank"><span class="icon-facebook"></span></a>
				<a class="side-rss" href="http://newsformat.jp/hd/traicy/http://www.traicy.com/feed" target="_blank"><span class="icon-rss"></span></a>
				<a class="side-feedly" href="https://feedly.com/i/subscription/feed%2Fhttp%3A%2F%2Fwww.traicy.com%2Findex.rdf" target="_blank"><span class="icon-feedly"></span></a>
				<a class="side-google-plus" href="https://plus.google.com/116492855879080319968/" target="_blank"><span class="icon-google-plus"></span></a>
				<a class="side-line" href="http://line.me/ti/p/%40traicy" target="_blank"><span class="icon-line"></span></a>
      </div>
  		<!-- <a href=""><div class="clear"></div></a> -->
  		<div class="clear"></div>
  	</div><!-- #header -->

    <div itemscope itemtype="http://schema.org/Article" id="page" class="hfeed site">

    <header id="masthead" class="site-header" role="banner">

    <div class="title_bar">

    <nav id="site-navigation" class="hide_o600 main-navigation fixed" role="navigation">

      <span class="hideSpan" itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
         <span itemprop="name"><?php wp_title(); ?></span>
         <span itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
           <span itemprop="url" itemtype="https://schema.org/ImageObject">https://www.traicy.com/images/logo.gif</span>
         </span>
      </span>

       <div class="header_set">
         <a href="<?php echo esc_url( home_url( '/' ) );?>"><amp-img class="header_logo" height="43.06" width="80" src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif"></a>

         <p class="amp_traicy_desc">航空・鉄道・ホテルなど旅行情報を<br>お送りするメディア。</p>
       </div>
       <div class="clear"></div>

    </nav><!-- #site-navigation -->

    </div>
  </header><!-- #masthead -->

	<div id="main" class="wrapper">

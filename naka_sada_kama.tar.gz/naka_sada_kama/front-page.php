<?php get_header(); ?>

<ul class="hide_o600"> <!-- sp -->
	<?php get_template_part( 'front-page-sp' ); ?>
</ul>
<ul class="hide_u600"> <!-- pc -->
	<?php get_template_part( 'front-page-pc' ); ?>
</ul>
<?php get_sidebar(); ?>
<?php get_footer(); ?>

<div id="siteSearch">
    <input type="text" id="siteSearchForm" placeholder="サイトを検索">
    <div id="siteSearchButton">◯</div>
  </div>
</div>

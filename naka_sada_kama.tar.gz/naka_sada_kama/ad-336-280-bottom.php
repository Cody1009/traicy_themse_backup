<!-- 600px以上1020px以下の場合表示 -->
<div class="hide_o600">
	<center>
	<!--広告-->
<script async defer src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- Traicy-New-Top-ArticleFooter-left -->
	<ins class="adsbygoogle"
		style="display:inline-block;width:300px;height:250px"
		data-ad-client="ca-pub-3121993718200907"
		data-ad-slot="7111125932"
		data-ad-region = "sq_3";>
	</ins>
<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</center>
</div>
<!-- 600px以上1020px以下の場合表示 -->

<ul class="hide_u600">
<table>
<tr>
<td>
  <div style="margin-right:0px;">
    <!--広告-->
<script type='text/javascript'>
<!--//<![CDATA[
   document.MAX_ct0 ='';
   var m3_u = (location.protocol=='https:'?'https://cas.criteo.com/delivery/ajs.php?':'http://cas.criteo.com/delivery/ajs.php?');
   var m3_r = Math.floor(Math.random()*99999999999);
   document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
   document.write ("zoneid=596489");document.write("&amp;nodis=1");
   document.write ('&amp;cb=' + m3_r);
   if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
   document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
   document.write ("&amp;loc=" + escape(window.location).substring(0,1600));
   if (document.context) document.write ("&context=" + escape(document.context));
   if ((typeof(document.MAX_ct0) != 'undefined') && (document.MAX_ct0.substring(0,4) == 'http')) {
       document.write ("&amp;ct0=" + escape(document.MAX_ct0));
   }
   if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
   var publisherurl = "%%SITE%%";
   var macro = "%%SI" + "TE%%";
   if (publisherurl !== macro) document.write ("&amp;publisherurl="+publisherurl);
   document.write ("'></scr"+"ipt>");
//]]>--></script>
  </div>
</td>
<td>
	<center style="margin-left:20px;">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Traicy-336-right-2 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-3121993718200907"
     data-ad-region = “traicy336-1"
     data-ad-slot="6977490333"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<?php /*
    <script type='text/javascript'>
       document.MAX_ct0 ='INSERT_CLICKURL_HERE';

    if (location.protocol=='https:') {
    } else {
       var m3_u = 'http://vsc.send.microad.jp/delivery/ajs.php';
       var m3_r = Math.floor(Math.random()*99999999999);
       if (!document.MAX_used) document.MAX_used = ',';
       document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
       document.write ("?zoneid=596494&amp;charset=UTF-8");
       document.write ('&amp;snr=2&amp;cb=' + m3_r);
       if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
       document.write ('&amp;charset=UTF-8');
       document.write ("&amp;loc=" + encodeURIComponent(window.location));
       if (document.referrer) document.write ("&amp;referer=" + encodeURIComponent(document.referrer));
       if (document.context) document.write ("&context=" + encodeURIComponent(document.context));
       if ((typeof(document.MAX_ct0) != 'undefined') && (document.MAX_ct0.substring(0,4) == 'http')) {
           document.write ("&amp;ct0=" + encodeURIComponent(document.MAX_ct0));
       }
       if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
       document.write ("'><\/scr"+"ipt>");
    }

</script><noscript><a href='http://vsc.send.microad.jp/delivery/ck.php?n=a1ffaf53&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://vsc.send.microad.jp/delivery/avw.php?zoneid=8003&amp;charset=UTF-8&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=a1ffaf53&amp;ct0=INSERT_CLICKURL_HERE&amp;snr=2' border='0' alt='' /></a></noscript>
 */?>
	</center>
</td>
</tr>
</table>
</ul>

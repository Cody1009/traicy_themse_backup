<?php global $myAmp; ?>

<?php
echo '<article  id="post-',the_ID(),'"',post_class(),'>';
if( is_sticky() && is_home() && !is_paged() ){
	echo '<div class="featured-post">';
	_e( 'Featured post', 'twentytwelve' );
	echo '<div>';
}
?>

	<?php if($myAmp): //AMPの場合-------------------------------------?>
		<?php // {{{ ?>
		<header class="entry-header">
			<span class="hideSpan" itemprop="image" itemscope itemtype="https://schema.org/ImageObject">
				<span class="hideSpan" itemprop="url"><?php the_post_thumbnail_url('medium'); ?></span>
				<span class="hideSpan" itemprop="width">400</span>
				<span class="hideSpan" itemprop="height">600</span>
			</span>
			<a href="<?php the_permalink(); ?>" rel="bookmark">
			<?php if ( ! post_password_required() && ! is_attachment() && ! is_single()) : ?>
				<?php the_post_thumbnail(); ?>
			<?php endif; ?>
			</a>

			<?php if ( is_single() ) : ?>
				<?php $tmp = get_the_category( '' ); ?>
				<div class="hide_o600">
				<?php foreach($tmp as $item) : ?>
						<span class="onlyCategory"><a href="<?php echo get_category_link( $item -> cat_ID ); ?>"><?php echo $item -> name; ?></a></span>
				<?php endforeach; ?>
				</div>
				<h1 itemprop="name" class="entry-title" itemprop="headline"><abbr itemprop='headline'><?php the_title(); ?></abbr></h1>
				<span class="hideSpan" itemprop="mainEntityOfPage"><?php the_permalink(); ?></span>

				<div class="date updated">
				<p>
					<span class="hideSpan" itemprop="datePublished"><?php echo get_the_time('c') ?></span>
					<span class="hideSpan" itemprop="dateModified"><?php echo get_the_modified_time('c') ?></span>
					<?php the_time('Y年n月j日 g:i a'); ?>
					<a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' ));?>" title="<?php get_the_author() ?>" class="vcard author">
						<span class="fn" itemprop="author" itemscope itemtype="http://schema.org/Person">
						<span itemprop="name"><?php echo get_the_author(); ?></span>
						</span>
					</a>
				</p>
				</div><!-- .date -->
				<!-- <h1 class="entry&#45;title"> -->
				<!--   <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a> -->
				<!-- </h1> -->
			<?php endif; // is_single() ?>

			<?php if ( comments_open() ) : ?>
				<div class="comments-link">
					<?php comments_popup_link( '<span class="leave-reply">' . __( 'Leave a reply', 'twentytwelve' ) . '</span>', __( '1 Reply', 'twentytwelve' ), __( '% Replies', 'twentytwelve' ) ); ?>
				</div><!-- .comments-link -->
            <?php endif; // comments_open() ?>
		</header><!-- .entry-header -->

		<!-- アイコンの挿入 -->
		<?php if ( is_single() ) :  ?>
			<div class="entry-content">
				<?php $content = get_the_content(); ?>
<?php
// {{{ 記事本文
$content = apply_filters( 'the_content', get_the_content() );
//echo $content;
$content = str_replace( ']]>', ']]&gt;', $content );
$content = preg_replace("/<img/i", "<amp-img width='300' height='200' layout='responsive'", $content);

// SNSのshareボタンを消す処理
// wordpressプラグインなのでif (!$myAmp)が書けないと思ったので追加
$result = preg_replace("/(<div class='wp_social_bookmarking_light'>.*?)<p>/", "<p>", $content);

echo $result;
// }}}
?>
				<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'twentytwelve' ), 'after' => '</div>' ) ); ?>

				<span class="sponsor">スポンサーリンク</span>

				<!-- ad st -->
				<center>
					<amp-ad
						type="adsense"
						width="300"
						height="250"
						data-ad-client="ca-pub-3121993718200907"
						data-ad-slot="6481590338"
					></amp-ad>
				</center>
				<!-- ad end -->
				<amp-analytics type="googleanalytics" id="analytics1">
                <script type="application/json">
                {
                  "vars": {
                    "account": "UA-24526458-1"
                  },
                  "triggers": {
                    "trackPageview": {
                      "on": "visible",
                      "request": "pageview"
                    }
                  }
                }
                </script>
				</amp-analytics>
			</div><!-- .entry-content -->
		<?php else : ?>
			<div class="entry-summary" itemprop="headline">
				<?php the_excerpt(); ?>
			</div><!-- .entry-summary -->
		<?php endif; ?>

		<footer>
			<div class="entry-meta tag_box">
			<?php the_tags('<p>タグ : ',' ','</p>'); ?>
			</div>

			<center>
				<amp-ad 
						type="popin"
						width=300
						height=568
						layout=responsive
						heights="(min-width:1907px) 39%, (min-width:1200px) 46%, (min-width:780px) 64%, (min-width:480px) 98%, (min-width:460px) 167%, 196%"
						data-mediaid="traicy_amp"
				></amp-ad>
				<amp-ad
					type="adsense"
					width="300"
					height="60"
					data-ad-client="ca-pub-3121993718200907"
					data-ad-slot="6481590338"
				></amp-ad>
			</center>
			<!-- ad end -->
		</footer><!-- .entry-meta -->
			

		<?php //}}} ?>

<?php else: //AMPでない場合-------------------------------------?>
<?php // {{{ ?>
			<header class="entry-header">
<?php if ( ! post_password_required() && ! is_attachment() && ! is_single()) : ?>
				<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_post_thumbnail(); ?></a>
<?php endif; ?>

<?php //記事が存在するかをチェック?>
<?php if ( is_single() ) : ?>

<div class="breadAndCat">
<?php breadcrumb(); ?>
<?php $tmp = get_the_category( '' ); ?>
<?php foreach($tmp as $item) : ?>
						<span class="category hide_u600"><a href="<?php echo get_category_link( $item -> cat_ID ); ?>"><?php echo $item -> name; ?></a></span>
<?php endforeach; ?>
</div>

<div class="hide_o600">
<?php foreach($tmp as $item) : ?>
						<span class="onlyCategory"><a href="<?php echo get_category_link( $item -> cat_ID ); ?>"><?php echo $item -> name; ?></a></span>
<?php endforeach; ?>
</div>

<?php	//タイトルを表示 ?>
				<h1 itemprop="name" class="entry-title" itemprop="headline"><abbr itemprop="headline"> <?php the_title(); ?></abbr></h1>
				<div class="date updated">
					<p>
<?php	//記事の更新日時を表示	?>
						<span itemprop="datePublished" content="',the_time('Y-n-jTg:i'),'"><?php the_time('Y年n月j日 g:i a'); ?></span>
<?php	//著者情報 ?>
<?php echo '<a href="',get_author_posts_url( get_the_author_meta( 'ID' ) ), '" title="',get_the_author(),'" class="vcard author"><span class="fn" itemprop="author" itemscope itemtype="http://schema.org/Person">',get_the_author(),'</span></a>'; ?>
					</p>
				</div>
<?php else : ?>
				<h1 class="entry-title">
<?php echo '<a href="',the_permalink(),'" rel="bookmark">',the_title(),'</a>'; ?>
				</h1>
<?php endif; ?>
			</header>

<?php if( is_single() ) : ?>
			<div class="entry-content">

<?php
	/**
	 * 中平作成のphpを使用して，SNSのマークをそれぞれ挿入
	 */ ?>
<?php include "share-buttons.php"; ?>
<?php 
// セール情報の場合はGoogleカレンダーに追加するボタンを表示
$startTime = strtotime(get_post_meta($id, 'CampaignStart' ,true));
$endTime   = strtotime(get_post_meta($id, 'CampaignEnd' ,true));

if ($startTime && $endTime):
  // google カレンダーのリンク用
  $baseUrl = "https://www.google.com/calendar/event?action=TEMPLATE&";
  $params = array(
    "text" => $post->post_title,
    "dates" => date('Ymd',  $startTime) . "/" . date('Ymd',  $endTime),
    "details" => $post->guid
  );
  $gcalenderUrl = $baseUrl . http_build_query($params);
?>

<div class="addGcalender singlePage">
  <a href="<?php echo $gcalenderUrl; ?>">
    <button><i class="fa fa-calendar-plus-o" aria-hidden="true"></i>&nbsp;Googleカレンダーに追加</button>
  </a>
</div>
<?php else: ?>
<div style="height: 10px;"></div>
<?php endif; ?>


<?php /**
	* 記事の表示　*/ ?>
<?php the_content( __( '<span class="meta-nav"></span>', 'twentytwelve' ) ); ?>

<?php /**
 * wifi価格比較を挿入
 */ ?>
<?php	get_template_part('wifi-article'); ?>

<?php /**
	ページを区切る方法
 */ ?>
<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'twentytwelve' ), 'after' => '</div>' ) ); ?>

<?php	/**
	 * 広告挿入
 */ ?>
				<span class="sponsor">スポンサーリンク</span>
<?php	if(!is_NoAdsense())	get_template_part('ad-336-280-bottom'); ?>
			</div> <!-- entry-content -->

			<footer class="entry-meta tag_box">
				<?php the_tags('<p>タグ : ',' ','</p>'); ?>
			</footer>

<?php
	/**
	 * 中平作成のphpを使用して，SNSのマークをそれぞれ挿入
	 */ ?>
<?php get_template_part('share-buttons'); ?>


<ul class="hide_o600">
<?php get_template_part( 'compe-box-sp' ); ?>
</ul>


<!-- popinタグ（レコメンド） -->
<?php /**
	 * popinのレコメンドが挿入される
	 * divのほうでjsを読み込んでくれている
 */ ?>
<div id="_popIn_recommend"></div>
	<script type="text/javascript">
	(function() {
		var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.charset = "utf-8"; pa.async = true;
		pa.src = window.location.protocol + "//api.popin.cc/searchbox/traicy.js";
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(pa, s);
	})(); 
	</script>
<!-- popinタグ（レコメンド） -->

<?php //ほとんど起きない条件 ?>
<?php else : ?>
		<div class="entry-summary" itemprop="headline">
			<?php the_excerpt(); ?>
		</div>
<?php endif; ?>


		<?php //}}} ?>
	<?php endif; //AMP分岐終わり-------------------------------------?>
</article><!-- #post -->

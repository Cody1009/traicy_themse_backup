<?php get_header(); ?>

<section id="primary" class="site-content">
<div id="content" role="main">

<header class="archive-header">
<h1 class="archive-title"><span class="catpage"><?php the_author(); ?></span> の記事一覧</h1>	
</header><!-- .archive-header -->

<?php if ( have_posts()) : ?>
<div class="allCategory">

<?php $count = 0; ?>
	<?php 
		while ( have_posts() ) : the_post();
			get_template_part( 'content-archive' );
			$count++;
		endwhile;
	?>

<?php $tmp = $count % 6; ?>
<?php switch( $tmp ){
	case 0 :
		break;
	case 1 :
?>
	<div class="catCards">
		<a href="<?php the_permalink(); ?>">
			<h1>空記事</h1>
			<img src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif">
			<p>空記事</p>
		<a>
	</div>
	<div class="catCards hide_u600">
		<a href="<?php the_permalink(); ?>">
			<h1>空記事</h1>
			<img src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif">
			<p>空記事</p>
		<a>
	</div>
<?php
		break;
	case 2 :
?>
	<div class="catCards hide_u600">
		<a href="<?php the_permalink(); ?>">
			<h1>空記事</h1>
			<img src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif">
			<p>空記事</p>
		<a>
	</div>
<?php
	case 3 :
?>
	<div class="catCards hide_o600">
		<a href="<?php the_permalink(); ?>">
			<h1>空記事</h1>
			<img src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif">
			<p>空記事</p>
		<a>
	</div>
<?php
		break;
	case 4 :
?>
<?php for($i=0;$i<2;$i++){ ?>
	<div class="catCards hide_u600">
		<a href="<?php the_permalink(); ?>">
			<h1>空記事</h1>
			<img src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif">
			<p>空記事</p>
		<a>
	</div>
<?php }
	break;
	case 5 :
?>
	<div class="catCards">
		<a href="<?php the_permalink(); ?>">
			<h1>空記事</h1>
			<img src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif">
			<p>空記事</p>
		<a>
	</div>
<?php
		break;
	} ?>


<?php	if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>

</div>
	<br style="clear:both;">
<?php endif; ?>

</div><!-- #content -->
</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>

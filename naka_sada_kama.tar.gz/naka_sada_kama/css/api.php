<?php
class isUniqueArrayFunction{
    // 配列内の全ての値が一意かチェックする
    function isUniqueArray($target_array){    
        $unique_array = array_unique($target_array);
        $alignedUnique = array_values($unique_array);
        return $alignedUnique;
    }
}
?>

<?php
    // エラーを画面に表示(1を0にすると画面上にはエラーは出ない)
    ini_set('display_errors',1);

    $base_url = "http://api.kakaku.com/mobile_data/world-wifi/api/searchXml/ver2/search/?key=NRWMVEUQG9NN335KVMGGACZE8BCT9C4V&";
    
    /*$param = array(
        "country" => "$_POST['country']",
        "use_days" => 1,
        "compensationType" => "$_POST['compensationType']",
        "receipt" => "$_POST['receiptStep']",
        "return" => 1
    );
    $param = array(
        "country" => 6,
        "use_days" => 1,
        "compensationType" => 7001,
        "receipt" => 1,
        "return" => 1
    );*/
    //$url = $base_url . http_build_query($param);
    $url = "http://api.kakaku.com/mobile_data/world-wifi/api/searchXml/ver2/search/?key=NRWMVEUQG9NN335KVMGGACZE8BCT9C4V&country=6&use_days=1&compensationType=7001&receipt=1&return=1";
        
    //xmlエラーを吐き出すとき
    $file = file_get_contents($url);
    $xml = preg_replace('/&(?=[a-z_0-9]+=)/m','&amp;',$file);
    $xmlData = simplexml_load_string($xml);

    /* 以下は，Xmlの中身を見たいときにコメントアウトを外してください．
    ini_set('xdebug.var_display_max_children', -1);
    ini_set('xdebug.var_display_max_data', -1);
    ini_set('xdebug.var_display_max_depth', -1);
    var_dump($xmlData);
    */

/*    print_r($result);
echo '<br/>';*/
/*    print_r($copyResult);
echo '<br/>';*/
    echo '<div id = "content" role = "main">';
	foreach($xmlData -> serviceList -> service as $itemValue){
        $resultName[] = (string)$itemValue->serviceName;
        $resultLineComment[] = (string)$itemValue -> lineComment;
    }
    $obj = new isUniqueArrayFunction;
    $copyResult = $obj -> isUniqueArray($resultName);
    
    $obj2 = new isUniqueArrayFunction;
    $copyResultLineComment = $obj2 -> isUniqueArray($resultLineComment);
    
    		//削除実行
		$copyResultLineComment = array_diff($copyResultLineComment, array('非公開'));
		//indexを詰める
		$copyResultLineComment = array_values($copyResultLineComment);

		print_r($copyResultLineComment);
        
    for($j=0;$j<(count($copyResultLineComment));$j++){
        $min = 100000;
        foreach($xmlData -> serviceList -> service as $itemValue){
		    if($copyResultLineComment[$j] === (string)$itemValue->lineComment){
		        if((int)$itemValue->rentalFee < $min){
		            $min = (int)$itemValue -> rentalFee;
		        }
		    }
        }
        foreach($xmlData -> serviceList -> service as $itemValue){
		    if($copyResultLineComment[$j] === (string)$itemValue->lineComment){
		        if((int)$itemValue->rentalFee == $min){
		            $save[] = $itemValue;
		        }
		    }
        }
    }
?>
<!-- コンテンツ -->
<article itemscope itemtype="http://schema.org/Article">

<div class = "new-entry">

<div itemprop="articleBody">
<section>
<div class = "capasity1">
<?php echo '<p>'.$copyResultLineComment[0].'</p>'; ?>
</div>
<div class ="photo">
<?php echo '<img src="'.$save['0'] -> serviceLogo.'">'; ?>
</div>
<span class = "money">
<?php echo '<p>'.$save[0]->rentalFee.'日/円</p>'; ?>
</span>
</section>
<section>
<div class = "capasity2">
<?php echo '<p>'.$copyResultLineComment[1].'</p>'; ?>
</div>
<div class ="photo">
<?php echo '<img src="'.$save['1'] -> serviceLogo.'">'; ?>
</div>
<span class = "money">
<?php echo '<p>'.$save[1]->rentalFee.'日/円</p>'; ?>
</span>
</section>
<section>
<div class = "capasity3">
<?php echo '<p>'.$copyResultLineComment[2].'</p>'; ?>
</div>
<div class ="photo">
<?php echo '<img src="'.$save['2'] -> serviceLogo.'">'; ?>
</div>
<span class = "money">
<?php echo '<p>'.$save[2]->rentalFee.'日/円</p>'; ?>
</span>
</section>
</div>
</div>

</article>

<?php
		for($i=0; $i<count($copyResult);$i++){ 
			echo '<div class = "both">サービス会社名 : '.$copyResult[$i].'</div>';
				$count = 0;
			foreach($xmlData -> serviceList -> service as $itemValue){
				if($copyResult[$i] === (string)$itemValue->serviceName){
					echo '<ul>';
          	echo '<li class = "line2c">';
          		echo '<a href="'.$itemValue -> detailUrl.'">';
								echo '<div class = "new-entry">';
									if($count == 0){
          					echo '<div class="new-entry-thumb left">';
            				echo '<img src="'.$itemValue -> serviceLogo.'">';
										echo '</div>';
								}
					echo '<div class="new-entry-content right title">';
										echo '<span class="hide_u600">';
						echo '<div itemprop="articleBody">';
						echo '<section><p>通信/レンタル費 : '.$itemValue -> rentalFee.'</p></section><br>';
											echo '<section><p>補償制度名称 : '.$itemValue -> compensationName.'</p></section><br>';
											echo '<section><p>補償制度費 : '.$itemValue -> compensationFee.'</p></section><br>';		
											echo '<section><p>補償制度コメント : '.$itemValue -> compensationComment.'</p></section><br>';		
											echo '<section><p>回線 : '.$itemValue -> lineType.'</p></section><br>';
											echo '</div>';
											echo '</span>';
						echo '</div>';
         				echo '</div>';
          		echo '</a>';
          	echo '</li>';
					echo '</ul>';
					$count = $count + 1;
				}

        }
    }
            
    echo '</div>';
?>

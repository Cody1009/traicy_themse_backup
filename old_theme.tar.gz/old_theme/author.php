<?php get_header(); ?>

<section id="primary" class="site-content">
<div id="content" role="main">

<header class="archive-header">
<h1 class="archive-title"><span class="catpage"><?php the_author(); ?></span> の記事一覧</h1>	
</header><!-- .archive-header -->

<?php if ( have_posts()) : ?>
	<?php 
		while ( have_posts() ) : the_post();
		get_template_part( 'content-archive', get_post_format());
		endwhile;
		if(function_exists('wp_pagenavi')) { wp_pagenavi(); }
	?>
	<br style="clear:both;">	
<?php endif; ?>

</div><!-- #content -->
</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>

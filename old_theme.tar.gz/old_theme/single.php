<?php
/**
 * The Template for displaying all single posts
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

get_header(); ?>
<?php global $myAmp; ?>
	<div id="primary" class="site-content">
		<div id="content" role="main" >
      <?php if(!$myAmp): ?>
        <meta itemprop="description" content="<?php echo get_post_meta($post->ID, _yoast_wpseo_metadesc, true); ?><?php $myExcerpt = get_the_excerpt(); if ($myExcerpt != '') {echo htmlspecialchars($myExcerpt, ENT_QUOTES);} ?>" />
        <meta itemprop="image" content="<?php echo wp_get_attachment_url( get_post_thumbnail_id() ); ?>">
      <?php endif;?>

			<?php while ( have_posts() ) : the_post(); ?>
        <?php get_template_part( 'content', get_post_format() ); ?>
      
        <!-- ad st -->
        <!-- <amp&#45;ad -->
        <!--   type="adsense" -->
        <!--   data&#45;ad&#45;client="ca&#45;pub&#45;3121993718200907" -->
        <!--   data&#45;ad&#45;slot="6481590338" -->
        <!--   data&#45;ad&#45;format="rectangle" -->
        <!-- ></amp&#45;ad> -->
        <!-- ad en -->
        
        <?php if($myAmp): ?>
          <nav class="nav-single">
            <div class="assistive-text"><?php _e( 'Post navigation', 'twentytwelve' ); ?></div>
            <?php previous_post_link( '%link', '<span class="nav-previous"><span class="meta-nav">' . _x( '&larr;', 'Previous post link', 'twentytwelve' ) . '</span> %title</span>' ); ?>
            <?php next_post_link( '%link', '<span class="nav-next">%title <span class="meta-nav">' . _x( '&rarr;', 'Next post link', 'twentytwelve' ) . '</span></span>' ); ?>
          </nav><!-- .nav-single -->
        <?php endif ?>

          <!-- single_facebook.phpに移動　鎌田寛 20160623 -->
        <?php comments_template( '', true ); ?>

			<?php endwhile; // end of the loop. ?>

		</div><!-- #content -->
	</div><!-- #primary -->

<?php if(!$myAmp): ?>
  <?php get_sidebar(); ?>
  <?php get_footer(); ?>
<?php endif; ?>

<?php
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );
function theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array('parent-style')
    );
}
//feedの文字数制限
/*
function adjust_text_for_feeds($content) {
	return wp_trim_words($content, 100, '…');
}

add_filter('the_excerpt_rss', 'adjust_text_for_feeds');
add_filter('the_content_feed', 'adjust_text_for_feeds');
*/
// カスタムメニューの定義 20160616 鎌田寛
register_nav_menus ( array (
        'gnav' => 'グローバルメニュー',
        'sub-nav' => 'サブメニュー',
));
/*
ナビゲーションの制御
*/
if (!is_admin()) {
    function register_script(){
        wp_deregister_script('twentytwelve-navigation');
        wp_register_script('twentytwelve-navigation', get_stylesheet_directory_uri().'/js/navigation.js', array(), '1.0', true);
    }
    function add_script() {
        register_script();
        wp_enqueue_script('twentytwelve-navigation');
    }
    add_action('wp_print_scripts', 'add_script');
}



/*
続きを読むの制御
*/


/**
 * feedのみwpautopを適用させない
 */
if (is_feed()) {
	remove_filter( 'the_content', 'wpautop' );
	remove_filter( 'the_excerpt', 'wpautop' );
}

/**
 * 続きを読むの文字数
 */
function custom_excerpt_length( $length ) {
	return 120;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

/**
 * 文末の[…]を変更する
 */
function new_excerpt_more($more) {
	return '  ... ';
}
add_filter('excerpt_more', 'new_excerpt_more');


// FeedWordPress用のexcerpt用の処理
function excerpt_for_feedwordpress($postExcerpt) {
	$excerptLength = custom_excerpt_length();
	$decodedExcerpt = strip_tags(html_entity_decode($postExcerpt, ENT_QUOTES, 'UTF-8'));
	if (mb_strlen($decodedExcerpt) <= $excerptLength) {
		return $decodedExcerpt;
	}
	return mb_substr($decodedExcerpt, 0, $excerptLength) . new_excerpt_more();
}
add_filter('get_the_excerpt', 'excerpt_for_feedwordpress');


/**
 * フッターにウィジェットエリアを作る
 */

// 親テーマの関数をremoveする関数
function remove_twentytwelve_widgets_init() {
    remove_action('widgets_init', 'twentytwelve_widgets_init');
}

// 上記の関数をWordPressのinitに登録
add_action('init','remove_twentytwelve_widgets_init');

// ウィジェット作る
function twentytwelve_widgets_init_child() {
    register_sidebar( array(
        'name' => __( 'Main Sidebar', 'twentytwelve' ),
        'id' => 'sidebar-1',
        'description' => __( 'Appears on posts and pages except the optional Front Page template, which has its own widgets', 'twentytwelve' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
/*
    register_sidebar( array(
        'name' => __( 'Main Sidebar2', 'twentytwelve' ),
        'id' => 'sidebar-4',
        'description' => __( 'Appears on posts and pages except the optional Front Page template, which has its own widgets', 'twentytwelve' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
    register_sidebar( array(
        'name' => __( 'First Front Page Widget Area', 'twentytwelve' ),
        'id' => 'sidebar-2',
        'description' => __( 'Appears when using the optional Front Page template with a page set as Static Front Page', 'twentytwelve' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    register_sidebar( array(
        'name' => __( 'Second Front Page Widget Area', 'twentytwelve' ),
        'id' => 'sidebar-3',
        'description' => __( 'Appears when using the optional Front Page template with a page set as Static Front Page', 'twentytwelve' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    register_sidebar( array(
        'name' => __( 'Footer Widget Area 1', 'twentytwelve' ),
        'id' => 'footer-widget-1',
        'description' => __( 'Widget area is displayed on a footer portion', 'twentytwelve' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    register_sidebar( array(
        'name' => __( 'Footer Widget Area 2', 'twentytwelve' ),
        'id' => 'footer-widget-2',
        'description' => __( 'Widget area is displayed on a footer portion', 'twentytwelve' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    register_sidebar( array(
        'name' => __( 'Footer Widget Area 3', 'twentytwelve' ),
        'id' => 'footer-widget-3',
        'description' => __( 'Widget area is displayed on a footer portion', 'twentytwelve' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    register_sidebar( array(
        'name' => __( 'Footer Widget Area 4', 'twentytwelve' ),
        'id' => 'footer-widget-4',
        'description' => __( 'Widget area is displayed on a footer portion', 'twentytwelve' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
 */
}

// カスタマイズした関数を有効化する
add_action('widgets_init','twentytwelve_widgets_init_child');

// フッターウィジェット
/*
function twentytwelve_footer_widget_class() {
    $count = 0;

    if ( is_active_sidebar( 'footer-widget-1' ) )
        $count++;

    if ( is_active_sidebar( 'footer-widget-2' ) )
        $count++;

    if ( is_active_sidebar( 'footer-widget-3' ) )
        $count++;

    if ( is_active_sidebar( 'footer-widget-4' ) )
        $count++;

    $class = '';

    switch ( $count ) {
        case '1':
            $class = 'one';
            break;
        case '2':
            $class = 'two';
            break;
        case '3':
            $class = 'three';
            break;
        case '4':
            $class = 'four';
            break;
    }

    if ( $class )
        echo $class;
}
 */

//オリジナルのfeedを追加(index.rdf)
/*
add_action('do_feed_indexrdf','do_feed_indexrdf');
function do_feed_indexrdf() {
$feed_template = get_stylesheet_directory(). '/feed-index-rdf.php';
load_template( $feed_template );
}
*/

function pj($data) {
	print_r(json_encode($data));
	exit;
}
// リリースカテゴリーのものはFeedに含めない
add_action('pre_get_posts', 'filter_for_feed');
function filter_for_feed($query) {
	if (!$query->is_feed() && !$query->is_home()) {
		return;
	}
	$filterCatSlug = 'release';
	$catData = get_category_by_slug($filterCatSlug);
	$filterCatId = sprintf('-%d', $catData->cat_ID);
	$query->set('cat', $filterCatId);
	return $query;
}

/**
 * リリースカテゴリーの記事のリンクの表示を置換
 * これに加えてRedirectionプラグインで"/release/(.*)$"へのアクセスを"/archives/$1"へ
 * リダイレクト(307 Path Through)させることで、擬似的にリリースカテゴリーのみパーマリンクをカスタムしている
 */
add_filter('post_link', 'replacePermalinkForRelease', 10, 2);
function replacePermalinkForRelease($permalink, $post) {
	$categories = array_filter(
		wp_get_post_categories($post->ID),
		function($c) {
			$cat = get_category($c);
			return ($cat->slug === 'release');
		}
	);
	if (empty($categories)) {
		return $permalink;
	}
	return _formatReleasePostLink($permalink);
}
// リリースカテゴリーの記事のリンクの表示を置換
function _formatReleasePostLink($link, $before = 'archives', $after = 'release') {
	$fmtLink = function($str) { return sprintf('/%s/', $str); };
	return str_replace($fmtLink($before), $fmtLink($after), $link);
}

//オリジナルのfeedを追加(スマートニュース)
add_action('do_feed_feedly', 'do_feed_feedly');
function do_feed_feedly() {
  $feed_template = get_stylesheet_directory(). '/feed-feedly.php';
  load_template( $feed_template );
}

//オリジナルのfeedを追加(スマートニュース)
add_action('do_feed_smartnews', 'do_feed_smartnews');
  function do_feed_smartnews() {
  $feed_template = get_stylesheet_directory(). '/feed-smartnews.php';
  load_template( $feed_template );
}

//オリジナルのfeedを追加(グノシー)
add_action('do_feed_gunosy', 'do_feed_gunosy');
function do_feed_gunosy() {
  $feed_template = get_stylesheet_directory() . '/feed-gunosy.php';
  load_template( $feed_template );
}

//オリジナルのfeedを追加(ミクシィ)
add_action('do_feed_mixi','do_feed_mixi');
function do_feed_mixi() {
  $feed_template = get_stylesheet_directory() . '/feed-mixi.php';
  load_template( $feed_template );
}

//オリジナルのfeedを追加(ニュースパス（旧名称：dailymedia）)
add_action('do_feed_newspass','do_feed_newspass');
function do_feed_newspass() {
  $feed_template = get_stylesheet_directory() . '/feed-newspass.php';
  load_template( $feed_template );
}

//feedを追加(Facebook Instant Articles)
add_action('do_feed_facebook', 'do_feed_facebook');
function do_feed_facebook() {
  $feed_template = get_stylesheet_directory() . '/feed-facebook.php';
  load_template( $feed_template );
}
//feedを追加(navitime plat)
add_action('do_feed_navitime', 'do_feed_navitime');
function do_feed_navitime() {
  $feed_template = get_stylesheet_directory() . '/feed-navitime-plat.php';
  load_template( $feed_template );
}
//feedを追加(skyticket)
add_action('do_feed_skyticket', 'do_feed_skyticket');
function do_feed_skyticket() {
  $feed_template = get_stylesheet_directory() . '/feed-skyticket.php';
  load_template( $feed_template );
}
//feedを追加(livedoor)
add_action('do_feed_livedoor', 'do_feed_livedoor');
function do_feed_livedoor() {
  $feed_template = get_stylesheet_directory() . '/feed-livedoor.php';
  load_template( $feed_template );
}

//画像アップエラー対策
add_filter('upload_post_params', 'custom_upload_post_params');
function custom_upload_post_params( $post_params )
{
    $post_params["short"]=0;
    $post_params["fetch"]=1;
    return $post_params;
}
//ヘッダーからwpバージョン削除
remove_action('wp_head', 'wp_generator');

//ヘッダーからEditURI を削除
remove_action('wp_head', 'rsd_link');

//ヘッダーからwlwmanifest を削除
remove_action('wp_head', 'wlwmanifest_link');

// アドセンスを非表示にする記事かどうかを判定する
function is_NoAdsense(){
  // カテゴリごと
  $category = get_the_category();
  $cat_id = $category[0]->cat_ID;
  if ($cat_id == 7786) {
    return true;
  }
  return false;
}

/* jsを非同期にする
if (!(is_admin() )) {
function add_async_to_enqueue_script( $url ) {
    if ( FALSE === strpos( $url, '.js' ) ) return $url;
    if ( strpos( $url, 'jquery.min.js' ) ) return $url;
    return "$url' async charset='UTF-8";
}
add_filter( 'clean_url', 'add_async_to_enqueue_script', 11, 1 );
}
*/

/* 記事ページ内ページャー制御 */

function custom_wp_link_pages() {

$defaults = array(
 'before' => '<div class="page-numbers">',
 'after' => '</div>',
 'link_before' => '',
 'link_after' => '',
 'next_or_number' => 'number',
 'separator' => ' ',
 'nextpagelink' => __( '次のページ »' ),
 'previouspagelink' => __( '« 前のページ' ),
 'pagelink' => '<span class="numbers">%</span>',
 'echo' => 1
 );
 return $defaults;
}
add_filter( 'wp_link_pages_args', 'custom_wp_link_pages');


/* ページャー以降の本文もfeedに読み込ませる　http://unguis.cre8or.jp/web/1279 */
function ftf_full_text_for_feeds($content) {
	if (!is_feed()) return $content;
	global $post;
	$content = $post->post_content;
	return $content;
}
add_filter( 'the_content', 'ftf_full_text_for_feeds', -100);

/**
 * スラッグの自動生成
 */
add_action('transition_post_status', 'triming_slug', 10, 3);
function triming_slug($new_status, $old_status, $post){
	if ($new_status === 'publish' && $old_status !== 'publish') {
		$now = new DateTime();
		$newpost = array();
		// ここでスラッグを指定
		$newpost['post_name'] = $now->format('Ymd') . $post->ID;
		$newpost['ID'] = $post->ID;
		wp_update_post($newpost);
	}
}

/* 続きを読む */

/* カテゴリ別新着 */
function cat_post_list( $args ) {
	global $post;
	$myposts = get_posts( $args );
	foreach( $myposts as $post ) {
		setup_postdata($post);
		?>
		<a href="<?php the_permalink(); ?>" class="new-entry-title clearfix">
		<li class="line2c">
		<div class="new-entry">
		  <div class="new-entry-thumb left">
		  	<?php if ( has_post_thumbnail()): // サムネイルを持っているときの処理 ?>
		  	  <?php the_post_thumbnail('thumbnail'); ?>
		  	<?php else: // サムネイルを持っていないときの処理 ?>
		  	  <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/dummy_600_400.jpg" alt="NO IMAGE" title="NO IMAGE"/>
		  	<?php endif; ?>
		  </div><!-- /.new-entry-thumb -->
		  <div class="new-entry-content right title">
				<?php the_title(); ?>
				<div class="line_up">
					<div class="date">
							<p><?php the_time('\'y n/j G:i'); ?></p>
					</div><!-- .date -->
				</div>
			</div><!-- /.new-entry-content -->
		</div><!-- /.new-entry -->
		</li><!-- /.line2c -->
		</a>
	<?php
	}
	wp_reset_postdata();
}

remove_filter( 'the_excerpt', 'wpautop' );

/*wp_social_bookmarkingのプラグインを除去　鎌田寛　20160628*/
function wp_sb_light(){
 $options = wp_social_bookmarking_light_options();
 $out = wp_social_bookmarking_light_output( $options['services'], get_permalink(), get_the_title() );
 echo $out;
 }
 
/*検索結果から除外*/
function fb_search_filter($query) {
  if ( !$query -> is_admin && $query -> is_search) {
    $query -> set('post__not_in', array(760) );
  }
  return $query;
}
add_filter( 'pre_get_posts', 'fb_search_filter' );

function search_wp_title( $title ) {
	if ( is_search() ) {
		$title = ' &raquo; 「' . get_search_query() . '」の検索結果 ';
	}
	return $title;
}
add_filter( 'wp_title', 'search_wp_title' );

//ここから 固定ページにphpを読み込ませるための関数
function Include_my_php($params = array()) {
    extract(shortcode_atts(array(
        'file' => 'default'
    ), $params));
    ob_start();
    include(get_theme_root() . '/' . get_template() . "/$file.php");
    return ob_get_clean();
}
 
add_shortcode('myphp', 'Include_my_php');
//ここまで


add_action('publish_post', 'add_post_meta_country');
/**
 * 記事が投稿された時に自動的にwifi広告用のメタデータを付与する
 */
function add_post_meta_country($post_id){
  $meta_key   = "wifi_country_id";

  // 記事のURLを取得
  $permalink = get_permalink($post_id);

  // スクリプトを実行して記事のタイトル（または内容）から国を検出して国IDを取得
  $meta_value = exec("/usr/local/src/rbenv/shims/ruby wp-content/themes/naka_sada_kama/detect_country.rb {$permalink}");
  $meta_value = (int) $meta_value;

  // カスタムフィールド（メタデータ）として国IDを付与
  if ( !add_post_meta($post_id, $meta_key, $meta_value) ) {
    update_post_meta ($post_id, $meta_key, $meta_value);
  }
}


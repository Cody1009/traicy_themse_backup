<?php
/*
Template Name: new-entry
*/
?>
<?php get_header() ?>
<section id="primary" class="site-content">
  <div id="content" role="main">
		 <?php the_post() ?>

		 <header class="archive-header">
   				<h1 class="archive-title"><?php printf( the_title() .'一覧' ); ?></h1>

   			<?php if ( category_description() ) : // Show an optional category description ?>
   				<div class="archive-meta"><?php echo category_description(); ?></div>
   			<?php endif; ?>
   			</header><!-- .archive-header -->
		<ul class="contents half_c sub_content">

		<?php

		$args = array(
		  'posts_per_page' => 15,
		  'order'=> 'DSC',
		  'paged' => $paged
		);
		?>

		<?php query_posts( $args ); ?>


		<?php if ( have_posts() ) : while ( have_posts() ) : the_post();	?>

		<a href="<?php the_permalink(); ?>" class="new-entry-title clearfix">
		<li class="line2c">

		<div class="new-entry">

			<div class="new-entry-thumb left">
			<?php if ( has_post_thumbnail()): // サムネイルを持っているときの処理 ?>
				<?php the_post_thumbnail('thumbnail'); ?>
			<?php else: // サムネイルを持っていないときの処理 ?>
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/dummy_600_400.jpg" alt="NO IMAGE" title="NO IMAGE"/>
			<?php endif; ?>
			</div><!-- /.new-entry-thumb -->

			<div class="new-entry-content right title">

				<p class="atitle"><!-- タイトルを表示 -->
				<?php the_title(); ?>
				</p>

						<span class="hide_u600"><!-- 内容を表示 -->
				<p>
				<?php the_excerpt(); ?>
				</p>
				</span>
				<div class="line_up">
					<div class="date">
							<p><?php the_time('\'y n/j G:i'); ?></p>
					</div><!-- .date -->

					<?php if (!is_null($cat)) : ?>
					<div class="delicious">
					<span><ul>
						<?php foreach((get_the_category()) as $cat){
							echo '<li>' . $cat->cat_name . '</li> '; } ?>
					</ul></span>
					</div>
					<?php endif; ?>
				</div>

			</div><!-- /.new-entry-content -->

		</div><!-- /.new-entry -->
		</li><!-- /.line2c　-->
		</a>

	  <?php endwhile; endif; ?>


		</ul>
		<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); }?>


		<?php wp_reset_query(); ?>


	  </div><!-- #content -->
   </section><!-- #primary -->
<?php get_sidebar() ?>
<?php get_footer() ?>

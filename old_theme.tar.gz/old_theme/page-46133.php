<?php
/**
 * header
 */ ?>

<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]>
<html <?php language_attributes(); ?>>
<!<![endif]-->
<?php // Loads HTML5 JavaScript file to add support for HTML5 elements in older IE versions. ?>
<!--[if lt IE 9]>
<script async defer src="<?php echo get_stylesheet_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->


<html lang="ja">
	<head prefix="og: http://ogp.me/ns# article: http://ogp.me/ns/article#">
		<title><?php wp_title( '|', true, 'right' ); ?></title>
		<link rel="shortcut icon" href="http://www.traicy.com/images/favicon.ico" />
		<!-- icon用cssの読み込み -->
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/icomoon/icomoon.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Facebook Instant Articles用 -->
		<meta property="fb:pages" content="135009769909270" />
		<meta property="fb:use_automatic_ad_placement" content="true">
		<link rel="alternate" type="application/rss+xml" title="トラベルメディア「Traicy（トライシー）」 &raquo; フィード"href="http://newsformat.jp/hd/traicy/http://www.traicy.com/feed" />

<?php
 /**
	* jQuery等の情報を読み込んでいる
	*/ ?>
	<?php wp_head(); ?>

<!-- シェアボタンfacebookいいね用 -->
		<div id="fb-root"></div>
<script async>(function(d, s, id) {
	var js, fjs = d.getElementsByTagName(s)[0];
	if (d.getElementById(id)) return;
	js = d.createElement(s); js.id = id;
	js.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.8";
	fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	<!-- シェアボタンfacebookいいね用 -->

	</head>

	<body <?php body_class(); ?>>
<script>(function(d, s, id) {
	var js, fjs = d.getElementsByTagName(s)[0];
	if (d.getElementById(id)) return;
	js = d.createElement(s); js.id = id;
	js.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.4&appId=113076798842836";
	fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	<!-- fbいいねBOX用 en -->

		<div id="header" class="hide_u600">
			<div class="header_text">
				<a href="/"><div>traicy</div></a>
				<a href="http://www.hotelers.jp/"><div>Hotelers</div></a>
				<a href="http://www.guesthousetoday.jp/"><div>GuesthouseToday</div></a>
				<a href="http://www.extrain.info/"><div>EX-TRAIN</div></a>
				<a href="http://www.traicy.com.tw/"><div>Traicy Taiwan</div></a>
			</div>
			<div class="social-icon">
				<a class="side-twitter" href="https://twitter.com/traicycom" target="_blank"><span class="icon-twitter"></span></a>
				<a class="side-facebook" href="https://www.facebook.com/traicycom" target="_blank"><span class="icon-facebook"></span></a>
				<a class="side-rss" href="http://newsformat.jp/hd/traicy/http://www.traicy.com/feed" target="_blank"><span class="icon-rss"></span></a>
				<a class="side-feedly" href="http://cloud.feedly.com/#subscription%2Ffeed%2Fhttp%3A%2F%2Fnewsformat.jp%2Fhd%2Ftraicy%2Fhttp%3A%2F%2Fwww.traicy.com%2Ffeed" target="_blank"><span class="icon-feedly"></span></a>
				<a class="side-google-plus" href="https://plus.google.com/116492855879080319968/" target="_blank"><span class="icon-google-plus"></span></a>
				<a class="side-line" href="http://line.me/ti/p/%40traicy" target="_blank"><span class="icon-line"></span></a>
			</div>
			<div class="clear"></div>
		</div><!-- #header -->

		<div itemscope itemtype="http://schema.org/Article" id="page" class="hfeed site">
			<header id="masthead" class="site-header" role="banner">
				<div class="title_bar">
					<nav id="site-navigation" class="hide_o600 main-navigation fixed" role="navigation">
						<span class="left"><a href="<?php echo esc_url( home_url( '/' ) );?>"><img class="header_logo" src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif"></a></span>
						<span class="sp_right">
							<button class="menu-toggle"><?php _e( 'Menu', 'twentytwelve' ); ?></button>
							<a class="assistive-text" href="#content" title="<?php esc_attr_e( 'Skip to content', 'twentytwelve' ); ?>"><?php _e( 'Skip to content', 'twentytwelve' ); ?></a>
							<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
						</span><!-- .sp_right -->
					</nav><!-- #site-navigation -->
					<a href="<?php echo esc_url( home_url( '/' ) );?>"><img class="header_logo hide_u600" src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif"></a>　
					<span class="clear"></span>
				</div><!-- .title_bar -->

<script>
	function oritatami(id){
		obj=(document.all)?document.all(id):((document.getElementById)?document.getElementById(id):null);
		if(obj) obj.style.display=(obj.style.display=="none")?"block":"none";
	}
</script>

				<nav id="site-navigation" class="main-navigation hide_u600 PC_nav" role="navigation">
					<span class="sp_right">
						<button class="menu-toggle"><?php _e( 'Menu', 'twentytwelve' ); ?></button>
						<a class="assistive-text" href="#content" title="<?php esc_attr_e( 'Skip to content', 'twentytwelve' ); ?>"><?php _e( 'Skip to content', 'twentytwelve' ); ?></a>
						<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
					</span><!-- .sp_right -->
				</nav><!-- #site-navigation -->
			</header><!-- #masthead -->

<script src="http://www.glam.jp/tun/gcontents.js" charset="utf-8"></script>
<div class="hide_u600" style="width : 900px; margin : 0 auto">
<script>
	insertContent('2000000009','', {'device':'pc','redirect':'http://www.traicy.com'});
</script>
</div>
<div class="hide_o600" style="width : 320px; margin : 0 auto">
<script>
	insertContent('2000000009','', {'device':'sp','redirect':'http://www.traicy.com'});
</script>
</div>

<?php
	/**
	 * footer
	 */ ?>

<?php
	 /**
		* The template for displaying the footer
		*
		* Contains footer content and the closing of the #main and #page div elements.
		*
		* @package WordPress
		* @subpackage Twenty_Twelve
		* @since Twenty Twelve 1.0
		*/
?>
	<footer id="colophon" role="contentinfo">


		<div class="site-info">
			<div class="about_traicy">
					<center>
						<span class="parent">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/ma.gif">
					<ul class="about">
						<li><a href="http://www.traicy.com/information">お知らせ</a></li>
						<li><a href="http://www.traicy.com/kiyaku">利用規約</a></li>
						<li><a href="http://www.traicy.com/article_provide">配信先一覧</a></li>
						<li><a href="http://www.traicy.com/writer">ライター一覧</a></li>
						<li><a href="http://www.traicy.com/ad">広告掲載</a></li>
						<li><a href="http://www.traicy.com/traicybloggernetwork">ブロガーネットワーク登録</a></li>
						<li><a href="http://www.traicy.com/mailmag">メルマガ登録</a></li>
						<!-- <li><a href="https://pushsan.com/applications/XTI572f731ee99a2">プッシュ通知（Android）</a></li> -->
						<li><a href="http://line.me/ti/p/%40traicy">LINE登録</a></li>
						<li><a href="http://www.traicy.com/wanted">採用情報</a></li>
						<li><a href="http://www.traicy.com/about#company">運営会社情報</a></li>
						<li><a href="http://www.traicy.com/contact">お問い合わせ</a></li>
					</ul>
					</center>
			</div><!-- .about_traicy -->
		</div><!-- .site-info -->


	</footer><!-- #colophon -->
</div><!-- #page -->

<?php //シェアボタン用のjsスクリプト ?>
<?php if( is_single() ): ?>

	<!-- fb, twitter, hatena, line, google+ -->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/share_buttons.js"></script>

	<!-- facebookいいねボタン -->
	<div id="fb-root"></div>
	 <script>(function(d, s, id) {
	 var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.8";
fjs.parentNode.insertBefore(js, fjs);
	 }(document, 'script', 'facebook-jssdk'));</script>

	 <?php endif; ?>

	 </body>
	 </html>


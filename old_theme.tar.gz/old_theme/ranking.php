<div id="topic">
  <h2 class="main_category">アクセスランキング</h2>
  <ul class="contents half_c sub_content">

    <?php

      $posts = wmp_get_popular( array( 'limit' => 5, 'post_type' => 'post', 'range' => 'daily' ) );
      global $post;
      if ( count( $posts ) > 0 ): foreach ( $posts as $post ): setup_postdata( $post );
      $cat = get_the_category();
      $cat = $cat[0];
      $cat_name = $cat->cat_name;
      ?>


    <a href="<?php the_permalink(); ?>" class="new-entry-title clearfix">
    <li class="line2c">

      <div class="new-entry">
        <div class="new-entry-thumb left sidebar_left">
        <?php if ( has_post_thumbnail() ): // サムネイルを持っているときの処理 ?>
          <?php the_post_thumbnail('thumbnail'); ?>
        <?php else: // サムネイルを持っていないときの処理 ?>
          <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/dummy_600_400.jpg" alt="NO IMAGE" title="NO IMAGE"/>
        <?php endif; ?>
        </div><!-- /.new-entry-thumb -->

        <div class="new-entry-content  title right sidebar_right">

          <?php the_title(); ?>

          <?php if (!is_null($cat)) : ?>
					<div class="line_up">
          <div class="delicious">
            <span class="nopri">
              <ul><li><?php echo $cat_name; ?></li></ul>
            </span>
            <span class="noside">
              <ul>
              <?php foreach((get_the_category()) as $cat){
                echo '<li>' . $cat->cat_name . '</li> '; } ?>
              </ul>
            </span>
          </div>
          </div>
          <?php endif; ?>

        </div><!-- /.new-entry-content -->
      </div><!-- /.new-entry -->
  </li><!-- /.line2c -->
  </a>

    <?php endforeach; endif; wp_reset_postdata(); ?>

  <?php wp_reset_query(); ?>

</ul><!-- contents half_c sub_content en-->

</div><!-- アクセスランキング en -->

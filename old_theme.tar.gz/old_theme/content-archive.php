<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>

<ul>
<?php

query_posts('posts_per_page=6&ignore_sticky_posts=0');

$termId = get_category_by_slug('information')->term_id;
$catArchiveUrl = get_term_link($termId , 'category'); //カテゴリーアーカイブのURL

?>



<li class="line2c">
	<a href="<?php the_permalink(); ?>" class="new-entry-title clearfix">

<div class="new-entry">

	<div class="new-entry-thumb left">
	<?php if ( has_post_thumbnail()): // サムネイルを持っているときの処理 ?>
		<?php the_post_thumbnail('thumbnail'); ?>
	<?php else: // サムネイルを持っていないときの処理 ?>
		<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/dummy_600_400.jpg" alt="NO IMAGE" title="NO IMAGE"/>
	<?php endif; ?>
	</div><!-- /.new-entry-thumb -->



	<div class="new-entry-content right title">		
		<?php if(mb_strlen($post->post_title, 'UTF-8') < 25){ ?>
			<p class="atitle">
			<?php echo $post->post_title; ?>
			</p>		
			<span class="hide_u600">
			<p><?php echo mb_substr(get_the_excerpt(), 0, 130); ?></p>
			</span>
		<?php }else if(mb_strlen($post->post_title, 'UTF-8') < 50){ ?>
			<p class="atitle">
			<?php echo $post->post_title; ?>
			</p>			
			<span class="hide_u600">
			<p><?php echo mb_substr(get_the_excerpt(), 0, 110); ?></p>
			</span>
		<?php }else if(mb_strlen($post->post_title, 'UTF-8') < 75){ ?>
			<p class="atitle">
			<?php echo $post->post_title; ?>
			</p>	
			<span class="hide_u600">
			<p><?php echo mb_substr(get_the_excerpt(), 0, 90); ?></p>
			</span>
		<?php }else{ ?>
			<p class="atitle">
			<?php echo $post->post_title; ?>
			</p>		
		<?php } ?>
			
		<div class="line_up">
		<div class="date">
		<p><?php the_time('\'y n/j G:i'); ?></p>
		</div><!-- .date -->
		</div>





	</div><!-- /.new-entry-content -->

</div><!-- /.new-entry -->
</a>
</li><!-- /.line2c -->




<?php wp_reset_query(); ?>
</ul>

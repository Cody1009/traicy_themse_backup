<?php 
# APIを叩いてマスタデータを取得
$target_url = "http://api.kakaku.com/mobile_data/world-wifi/api/searchXml/ver2/master/?key=NRWMVEUQG9NN335KVMGGACZE8BCT9C4V";
$xml = simplexml_load_file($target_url);
?>

<?php
function getFoo($input){
	if($input == "フォートラベル GLOBAL WiFi")	return "フォートラベル";
	return $input;
}
?>
<?php
#{{{
$country = array(
	"アメリカ" => 6,
	"韓国" => 94,
	"中国" => 102,
	"カナダ" => 23,
	"インド" => 91,
	"インドネシア（バリ島以外の全域）" => 92,
	"インドネシア（バリ島）" => 93,
	"タイ" => 99,
	"台湾" => 100,
	"フィリピン" => 109,
	"ベトナム" => 112,
	"マレーシア（マレー半島主要都市）" => 115,
	"マレーシア（ボルネオ島及び全域）" => 116,
	"イギリス" => 144,
	"イタリア" => 149,
	"オーストラリア" => 79,
	"スペイン" => 170,
	"ドイツ" => 178,
	"フランス" => 184,
	"香港" => 113,
	"ハワイ" => 61,
	"グアム" => 29,
	"選択なし" => 0,
);
#}}}
?>

<?php
// エラーを画面に表示(1を0にすると画面上にはエラーは出ない)
ini_set('display_errors',1);
?>

<?php
$str = get_post_meta($post->ID, 'Country', true);
//$str = "アメリカ";
$tmp = $country[$str];
//var_dump($str);
if($tmp != 0 &&	count($str) != 0)   :
?>

<?php
$base_url = "http://api.kakaku.com/mobile_data/world-wifi/api/searchXml/ver2/search/?key=NRWMVEUQG9NN335KVMGGACZE8BCT9C4V&";
$param = array(
	"country" => $tmp,
	"use_days" => 1,
	"compensationType" => 7001,
	"receipt" => 1,
	"return" => 1
);
$url = $base_url . http_build_query($param);

$file = file_get_contents($url);
$xml = preg_replace('/&(?=[a-z_0-9]+=)/m','&amp;',$file);
$xmlData = simplexml_load_string($xml);
?>
	<!-- コンテンツ -->

<?php //echo '<div class="entry-content">'; ?>

<?php echo '<span class="countryTitle">',$str,'のWifi価格比較</span>'; ?>

<?php
	echo '<div class="hide_u600 wificompeL">';
	echo '<div class="container">';
foreach($xmlData -> serviceList -> service as $itemValue){
	echo '<a href = "',$itemValue -> detailUrl,'">';
	echo '<div class="item">';
	echo '<div class="logo"><img src="',$itemValue -> serviceLogo,'" class="imageLogo"></div>';
	echo '<div class="information">';
	echo '<p class="comTitle">',$itemValue -> serviceName,'</p>';
	if((string)($itemValue -> kakakuCampaignFlg) === "1"){
		echo '<p class="kakakuTitle">価格.com限定価格</p>';
	}else{
		echo '<p class="kakakuTitle"><br></p>';
	}
	echo '<p class = "lineSpeed">回線速度&nbsp;:&nbsp;',$itemValue -> lineType, '</p>';
	echo '<p class = "lineCapasity">',$itemValue -> lineComment,'</p>';
	echo '<p class = "lineCost"><span style="font-size:10px">１日あたり</span>&yen;',$itemValue -> rentalFee,'</p>';
	echo '</div>';
	echo '</div>';
	echo '</a>';
}
	echo '</div>';
	echo '</div>';
?>
<?php
	echo '<div class="hide_o600 wificompeS">';
	echo '<div class="container">';
foreach($xmlData -> serviceList -> service as $itemValue){
	echo '<a href = "',$itemValue -> detailUrl,'">';
	echo '<div class="item">';
	echo '<div class="logo"><img src="',$itemValue -> serviceLogo,'" class="imageLogo"></div>';
	echo '<div class="information">';
	echo '<p class="comTitle">',getFoo($itemValue -> serviceName),'</p>';
	if((string)($itemValue -> kakakuCampaignFlg) === "1"){
		echo '<p class="kakakuTitle">価格.com限定価格</p>';
	}else{
		echo '<p class="kakakuTitle"><br></p>';
	}
	echo '<p class = "lineSpeed">回線速度&nbsp;:&nbsp;',$itemValue -> lineType, '</p>';
	echo '<p class = "lineCapasity">',$itemValue -> lineComment,'</p>';
	echo '<p class = "lineCost"><span style="font-size:10px">１日あたり</span>&yen;',$itemValue -> rentalFee,'</p>';
	echo '</div>';
	echo '</div>';
	echo '</a>';
}
	echo '</div>';
	echo '</div>';
?>
<?php ?>

<?php 
	endif;
?>

<?php //echo '</div>'; ?>




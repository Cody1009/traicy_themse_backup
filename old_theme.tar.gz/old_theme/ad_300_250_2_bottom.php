<script async defer src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 600px以上1020px以下の場合表示 -->
<div class="hide_o1020">
  <center>
    <!--広告-->
    <!-- Traicy-New-Top-ArticleFooter-left -->
    <ins class="adsbygoogle"
         style="display:inline-block;width:300px;height:250px;"
         data-ad-client="ca-pub-3121993718200907"
         data-ad-slot="7111125932"
         data-ad-region = "sq_3";>
        </ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
  </center>
</div>
<!-- 600px以上1020px以下の場合表示 -->

<!-- 1020px以上の場合表示 -->
<table class="hide_u1020">
<tr>
<td>
  <center style="margin-right:0px;">
    <!--広告-->
    <!-- Traicy-PC-Top-Under-left -->
    <ins class="adsbygoogle"
         style="display:inline-block;width:300px;height:250px;"
         data-ad-client="ca-pub-3121993718200907"
         data-ad-slot="3504587137"
         data-ad-region = "sq_4"></ins>
    <script>
      (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
  </center>
</td>
<td>
  <center style="margin-left:10px;">
    <!-- Traicy-PC-Top-Under-Right -->
    <ins class="adsbygoogle"
         style="display:inline-block;width:300px;height:250px;"
         data-ad-client="ca-pub-3121993718200907"
         data-ad-slot="4981320335"
         data-ad-region = "sq_5"></ins>
    <script>
      (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
  </center>
</td>
</tr>
</table>
<!-- 1020px以上の場合表示 -->

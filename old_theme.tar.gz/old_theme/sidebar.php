<?php
/**
 * The sidebar containing the main widget area
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
<div id="sidebar" class="hide_u600" style="float:right;">
	<div id="scroll">

	<?php if(!is_NoAdsense()) { ?>
	<script type='text/javascript'>
<!--//<![CDATA[
document.MAX_ct0 ='';
var m3_u = (location.protocol=='https:'?'https://cas.criteo.com/delivery/ajs.php?':'http://cas.criteo.com/delivery/ajs.php?');
var m3_r = Math.floor(Math.random()*99999999999);
document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
document.write ("zoneid=421708");document.write("&amp;nodis=1");
document.write ('&amp;cb=' + m3_r);
if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
document.write ("&amp;loc=" + escape(window.location).substring(0,1600));
if (document.context) document.write ("&context=" + escape(document.context));
if ((typeof(document.MAX_ct0) != 'undefined') && (document.MAX_ct0.substring(0,4) == 'http')) {
	document.write ("&amp;ct0=" + escape(document.MAX_ct0));
}
if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
var publisherurl = "%%SITE%%";
var macro = "%%SI" + "TE%%";
if (publisherurl !== macro) document.write ("&amp;publisherurl="+publisherurl);
document.write ("'></scr"+"ipt>");
//]]>--></script>
		<?php } ?><!-- /広告 -->

<a href="http://www.traicy.com/wifi"><img src="http://www.traicy.com/images/banner.jpg" width = "100%" height = "auto" style = "margin: 10px 0;"></a>

	<?php get_template_part('ranking');?><!-- ランキング -->

<div id="topic" >
	<h2 class="main_category">Follow me!</h2>
	<div class="social-icon">
		<a class="side-twitter" href="https://twitter.com/traicycom" target="_blank"><i class="icon-twitter"></i>twitter</a>
		<a class="side-facebook" href="https://www.facebook.com/traicycom" target="_blank"><i class="icon-facebook"></i>facebook</a>
		<a class="side-rss" href="http://newsformat.jp/hd/traicy/http://www.traicy.com/feed" target="_blank"><i class="icon-rss"></i>RSS</a>
		<a class="side-feedly" href="http://cloud.feedly.com/#subscription%2Ffeed%2Fhttp%3A%2F%2Fnewsformat.jp%2Fhd%2Ftraicy%2Fhttp%3A%2F%2Fwww.traicy.com%2Ffeed" target="_blank"><i class="icon-feedly"></i>feedly</a>
		<a class="side-google-plus" href="https://plus.google.com/116492855879080319968/" target="_blank"><i class="icon-google-plus"></i>google+</a>
		<a class="side-line" href="http://line.me/ti/p/%40traicy" target="_blank"><i class="icon-line"></i>Line</a>
	</div>
</div>


	<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
		<div id="secondary" class="widget-area" role="complementary">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div><!-- #secondary -->
	<?php endif; ?><!-- /メインウィジェット１ -->



	</div><!-- #scroll -->

</div><!-- #sidebar -->

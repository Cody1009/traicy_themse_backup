<?php
class isUniqueArrayFunction{
	// 配列内の全ての値が一意かチェックする
	function isUniqueArray($target_array){    
		$unique_array = array_unique($target_array);
		$alignedUnique = array_values($unique_array);
		return $alignedUnique;
	}
}
?>

<?php
if(isset($_POST['country'])) : 
?>

<?php
	// エラーを画面に表示(1を0にすると画面上にはエラーは出ない)
	//ini_set('display_errors',1);

	$base_url = "http://api.kakaku.com/mobile_data/world-wifi/api/searchXml/ver2/search/?key=NRWMVEUQG9NN335KVMGGACZE8BCT9C4V&";    
	$param = array(
		"country" => $_POST['country'],
		"use_days" => $_POST['use_days'],
		"compensationType" => $_POST['compensationType'],
		"receipt" => $_POST['receipt'],
		"return" => $_POST['returnPlace']
	);
	if(count($_POST) == 2){
		$param = array(
			"country" => $_POST['country'],
			"use_days" => $_POST['use_days'],
			"compensationType" => 7001,
			"receipt" => 1,
			"return" => 1
		);
	}

	$url = $base_url . http_build_query($param);

	$file = file_get_contents($url);
	$xml = preg_replace('/&(?=[a-z_0-9]+=)/m','&amp;',$file);
	$xmlData = simplexml_load_string($xml);

		/* 以下は，Xmlの中身を見たいときにコメントアウトを外してください．
		ini_set('xdebug.var_display_max_children', -1);
		ini_set('xdebug.var_display_max_data', -1);
		ini_set('xdebug.var_display_max_depth', -1);
		var_dump($xmlData);
		 */

	echo '<div id = "content" role = "main">';
	foreach($xmlData -> serviceList -> service as $itemValue){
		$resultName[] = (string)$itemValue->serviceName;
		$resultLineComment[] = (string)$itemValue -> lineComment;
	}
	$obj = new isUniqueArrayFunction;
	$copyResult = $obj -> isUniqueArray($resultName);

	$obj2 = new isUniqueArrayFunction;
	$copyResultLineComment = $obj2 -> isUniqueArray($resultLineComment);

	//削除実行
	//$copyResultLineComment = array_diff($copyResultLineComment, array('非公開'));
	$tmp = 0;
	$copyResultLineCommentTmp = array_fill(0,3,"");
	for($i=0;$i<count($copyResultLineComment);$i++){
		if($copyResultLineComment[$i] === '250MB/日' || $copyResultLineComment[$i] === '500MB/日' || $copyResultLineComment[$i] === '1GB/日'){
			$copyResultLineCommentTmp[$tmp] = $copyResultLineComment[$i];
			$tmp++;
		}
	}
	$copyResultLineComment = null;
	//indexを詰める
	$copyResultLineComment = array_values($copyResultLineCommentTmp);

	
	for($j=0;$j<(count($copyResultLineComment));$j++){
		$min = 100000;
		foreach($xmlData -> serviceList -> service as $itemValue){
			if(($itemValue -> lineType) == '4G'){
				if($copyResultLineComment[$j] === (string)$itemValue->lineComment){
					if((int)$itemValue->rentalFee < $min){
						$min = (int)$itemValue -> rentalFee;
					}
				}
			}
		}
		foreach($xmlData -> serviceList -> service as $itemValue){
			if($itemValue -> lineType == '4G'){
				if($copyResultLineComment[$j] === (string)$itemValue->lineComment){
					if((int)$itemValue->rentalFee == $min){
						$save[] = $itemValue;
					}
				}
			}
		}
	}
?>
<!-- コンテンツ -->
<article itemscope itemtype="http://schema.org/Article">

<div class = "new-entry">

<?php echo '<p class = "titleCompasion">'.$xmlData -> parameter -> areaName.' Wifi価格比較 <span class="hide_u600">回線速度4G</span> 容量別 最安価格</p>'; ?>
<span class="hide_u600">
<div itemprop="articleBody">
<section>
<?php echo '<a href="'.$save[0] -> applyUrl.'">'; ?>
<div class = "capasity1">
<?php echo '<p>250<span class = "perCostDay">MB/日</span></p>'; ?>
</div>
<div class ="photo">
<?php echo '<img src="'.$save['0'] -> serviceLogo.'">'; ?>
</div>
<span class = "money">
<?php echo '<p>'.((double)($save[0]->rentalFee) / (double)($_POST['use_days'])).'<span class = "perCostDay">円/日</span></p>'; ?>
</span>
</a>
</section>
<section>
<?php echo '<a href="'.$save[1] -> applyUrl.'">'; ?>
<div class = "capasity2">
<?php echo '<p>500<span class = "perCostDay">MB/日</span></p>'; ?>
</div>
<div class ="photo">
<?php echo '<img src="'.$save['1'] -> serviceLogo.'">'; ?>
</div>
<span class = "money">
<?php echo '<p>'.((double)($save[1]->rentalFee) / (double)($_POST['use_days'])).'<span class = "perCostDay">円/日</span></p>'; ?>
</span>
</a>
</section>
<section>
<?php echo '<a href="'.$save[2] -> applyUrl.'">'; ?>
<div class = "capasity3">
<?php echo '<p>1<span class = "perCostDay">GB/日</span></p>'; ?>
</div>
<div class ="photo">
<?php echo '<img src="'.$save['2'] -> serviceLogo.'">'; ?>
</div>
<span class = "money">
<?php	echo '<p>'.((double)($save[2]->rentalFee) / (double)($_POST['use_days'])).'<span class = "perCostDay">円/日</span></p>'; ?>
</span>
</a>
</section>
</div>
</span>
</article>

<?php echo '<span class="hide_u600"><p class="titleTabCompasion">容量別 価格比較</p></span>'; ?>

<ul class="contents half_c sub_content">
<div id="tabnavi">
	<ul>
		<li><a href="#tab01">250MB/日</a></li>
		<li><a href="#tab02">500MB/日</a></li>
		<li><a href="#tab03">1GB/日</a></li>
	</ul>
</div>
<div id="tabcontent">
<?php	//var_dump($save); ?>

<?php
	for($i=1;$i<=3;$i++){
		$tabId = sprintf("tab0%d",$i);
		echo '<div id="'.$tabId.'">';
		foreach($xmlData -> serviceList -> service as $itemValue){
			if($copyResultLineComment[$i-1] === (string)$itemValue->lineComment){
				echo '<ul>';
				echo '<li class = "line2c">';
				echo '<a href="'.$itemValue -> applyUrl.'">';
				echo '<div class = "new-entry">';
				echo '<div class="new-entry-thumb left">';
				echo '<img src="'.$itemValue -> serviceLogo.'">';
				echo '</div>';
				echo '<div class="new-entry-content right title">';
				$cost = (double)$itemValue -> rentalFee;
				$cost /= (double)$_POST['use_days'];
				echo '<div class ="costHikaku">';
				if((string)$itemValue -> kakakuCampaignFlg === "1"){
					echo '<p class = "atitle">',$itemValue -> serviceName,'&nbsp;&nbsp;',$itemValue -> planName,'&nbsp;&nbsp;<span class ="kakaku">価格.com限定価格!!&nbsp;&nbsp;',($itemValue -> lineType) == "3G" ? "3G" : "",'</span></p>';
				}else{
					echo '<p class = "atitle">'.$itemValue -> serviceName.'&nbsp;&nbsp;&nbsp;'.$itemValue -> planName.'&nbsp;&nbsp;<span class = "kakaku">',($itemValue -> lineType) == "3G" ? "3G" : "",'</span></p>';
				}
				echo '</div>';
				echo '<p class = "fee"><span class = "perCost">料金&nbsp;:&nbsp;</span>'.$cost.'&nbsp;<span class = "perCost">円&nbsp;(1日あたり)</span>';
				echo '<span class="hide_u600">';
				echo '<span class = "perCost">&nbsp;&nbsp;&nbsp;'. (string)$_POST['use_days'].'日間総額&nbsp;:&nbsp;</span>'.$itemValue -> rentalFee.'<span class = "perCost">円</span></p>';
				echo '</span>';
				echo '<span class="hide_u600">';
				if(((int)$itemValue -> compensationFee) > 0){
					$comment =(string)$itemValue -> compensationComment;
					$num = strpos($comment, "※");
					echo '<p class = "compensation">補償費&nbsp;:&nbsp;'.$itemValue -> compensationFee.'円</br><span class="compensationComment">';
					for($j = 0; $j < mb_strlen($comment)*5; $j++){
						if($j == $num && $num != 0)    echo '<br>';
						echo $comment[$j];
					}
					echo '</span></p>';
				}else{
					echo ' ';
				}
				echo '</span>';
				echo '</div>';
				echo '</div>';
				echo '</a>';
				echo '</li>';
				echo '</ul>';
			}
		}
		echo '</div>';
	}
	echo '<p class = caution>注意 : 価格.comのページにリンクします</p>';
?>
<p class = "titleTabCompasion">通信容量の目安</p>
<table cellspacing="0" style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.5em; padding-top: 0.5em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em; background-color : #FFFFFF; width: 100%">
	<tbody>
		<tr>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em; width: 30%; color : #0D79CC; background-color: #eeeeee" >
				<p style="font-size: calc(1.0vw); font-height: calc(1.0vw)">
					<strong>データ通信量（500MB）</strong></p>
			</td>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em; color : #0D79CC; background-color: #eeeeee">
				<p style="font-size: calc(12px); font-height: calc(12px)">
					<strong>利用可能目安</strong></p>
			</td>
		</tr>
		<tr>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em">
				<p style="font-size: calc(10px+0.5vw); font-height: calc(10px+0.5vw)">
					メール</p>
			</td>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em">
					<br>
				<p style="font-size: calc(10px+0.5vw); font-height: calc(10px+0.5vw)">
					約1,000通</p>
					<br>
			</td>
		</tr>
		<tr>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em">
				<p style="font-size: calc(10px+0.5vw); font-height: calc(10px+0.5vw)">
					GoogleMap</p>
			</td>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em">
					<br>
				<p style="font-size: calc(10px+0.5vw); font-height: calc(10px+0.5vw)">
					約400km</p>
					<br>
			</td>
		</tr>
		<tr>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em">
				<p style="font-size: calc(10px+0.5vw); font-height: calc(10px+0.5vw)">
					動画</p>
			</td>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em">
					<br>
				<p style="font-size: calc(10px+0.5vw); font-height: calc(10px+0.5vw)">
					約2.2時間</p>
					<br>
			</td>
		</tr>
		<tr>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em">
				<p style="font-size: calc(10px+0.5vw); font-height: calc(10px+0.5vw)">
					ニュースサイト閲覧</p>
			</td>
			<td style="border-top: rgb(0,0,0) 1px solid; border-right: rgb(0,0,0) 1px solid; vertical-align: middle; border-bottom: rgb(0,0,0) 1px solid; padding-bottom: 0.2em; text-align: center; padding-top: 0.2em; padding-left: 0.5em; border-left: rgb(0,0,0) 1px solid; padding-right: 0.5em">
					<br>
				<p style="font-size: calc(10px+0.5vw); font-height: calc(10px+0.5vw)">
					約1,700ページ</p>
					<br>
			</td>
		</tr>
	</tbody>
</table>
</div>
</ul>

<?php 
else :
endif;
?>

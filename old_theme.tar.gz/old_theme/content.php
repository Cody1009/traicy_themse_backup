<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>

<?php global $myAmp; ?>

<?php
    echo '<article  id="post-',the_ID(),'"',post_class(),'>';
    if( is_sticky() && is_home() && !is_paged() ){
        echo '<div class="featured-post">';
        _e( 'Featured post', 'twentytwelve' );
        echo '<div>';
    }
?>

  <?php if($myAmp): //AMPの場合-------------------------------------?>
    <?php // {{{ ?>
    <header class="entry-header">
      <span class="hideSpan" itemprop="image" itemscope itemtype="https://schema.org/ImageObject">
        <span class="hideSpan" itemprop="url"><?php the_post_thumbnail_url('medium'); ?></span>
        <span class="hideSpan" itemprop="width">400</span>
        <span class="hideSpan" itemprop="height">600</span>
      </span>
      <a href="<?php the_permalink(); ?>" rel="bookmark">
      <?php if ( ! post_password_required() && ! is_attachment() && ! is_single()) : ?>
        <?php the_post_thumbnail(); ?>
      <?php endif; ?>
      </a>

      <?php if ( is_single() ) : ?>
        <div class="delicious">
          <?php the_category(''); ?>
        </div>
        <h1 itemprop="name" class="entry-title" itemprop="headline"><abbr itemprop='headline'><?php the_title(); ?></abbr></h1>
        <span class="hideSpan" itemprop="mainEntityOfPage"><?php the_permalink(); ?></span>

        <div class="date updated">
        <p>
          <span class="hideSpan" itemprop="datePublished"><?php echo get_the_time('c') ?></span>
          <span class="hideSpan" itemprop="dateModified"><?php echo get_the_modified_time('c') ?></span>
          <?php the_time('Y年n月j日 g:i a'); ?>
          <a href="<?php echo get_author_posts_url(get_the_author_meta( 'ID' ));?>" title="<?php get_the_author() ?>" class="vcard author">
            <span class="fn" itemprop="author" itemscope itemtype="http://schema.org/Person">
            <span itemprop="name"><?php echo get_the_author(); ?></span>
            </span>
          </a>
        </p>
        </div><!-- .date -->
        <!-- <h1 class="entry&#45;title"> -->
        <!--   <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a> -->
        <!-- </h1> -->
      <?php endif; // is_single() ?>

      <?php if ( comments_open() ) : ?>
        <div class="comments-link">
          <?php comments_popup_link( '<span class="leave-reply">' . __( 'Leave a reply', 'twentytwelve' ) . '</span>', __( '1 Reply', 'twentytwelve' ), __( '% Replies', 'twentytwelve' ) ); ?>
        </div><!-- .comments-link -->
      <?php endif; // comments_open() ?>
    </header><!-- .entry-header -->

    <!-- アイコンの挿入 -->
    <?php if ( is_single() ) :  ?>
      <div class="entry-content">
        <?php $content = get_the_content(); ?>
        <?php
          // {{{ 記事本文
          $content = apply_filters( 'the_content', get_the_content() );
          //echo $content;
          $content = str_replace( ']]>', ']]&gt;', $content );
          $content = preg_replace("/<img/i", "<amp-img width='300' height='200' layout='responsive'", $content);

          // SNSのshareボタンを消す処理
          // wordpressプラグインなのでif (!$myAmp)が書けないと思ったので追加
          $result = preg_replace("/(<div class='wp_social_bookmarking_light'>.*?)<p>/", "<p>", $content);

          echo $result;
          // }}}
        ?>
        <?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'twentytwelve' ), 'after' => '</div>' ) ); ?>

        <span class="sponsor">スポンサーリンク</span>
      
        <!-- ad st -->
        <center>
          <amp-ad
            type="adsense"
            width="300"
            height="250"
            data-ad-client="ca-pub-3121993718200907"
            data-ad-slot="6481590338"
          ></amp-ad>
        </center>
        <!-- ad end -->
        <amp-analytics type="googleanalytics" id="analytics1">
        <script type="application/json">
        {
          "vars": {
            "account": "UA-24526458-1"
          },
          "triggers": {
            "trackPageview": {
              "on": "visible",
              "request": "pageview"
            }
          }
        }
        </script>
        </amp-analytics>

      </div><!-- .entry-content -->
    <?php else : ?>
      <div class="entry-summary" itemprop="headline">
        <?php the_excerpt(); ?>
      </div><!-- .entry-summary -->
    <?php endif; ?>

    <footer class="entry-meta tag_box">
      <?php the_tags('<p>タグ : ',' ','</p>'); ?>

      <!-- ad st -->
      <center>
        <amp-ad
          type="adsense"
          width="300"
          height="60"
          data-ad-client="ca-pub-3121993718200907"
          data-ad-slot="6481590338"
        ></amp-ad>
      </center>
      <!-- ad end -->
    </footer><!-- .entry-meta -->

    <?php //}}} ?>
  <?php else: //AMPでない場合-------------------------------------?>
<?php // {{{ ?>
    <?php	
      echo '<header class="entry-header">';
          if ( ! post_password_required() && ! is_attachment() && ! is_single()){
              echo '<a href="',the_permalink(),'rel="bookmark">',the_post_thumbnail(),'</a>';
          }
          //記事が存在するかをチェック
          if (is_single() ){
              //カテゴリの一覧を表示
              echo '<div class="delicious">',the_category(''),'</div>';
              //タイトルを表示
              echo '<h1 itemprop="name" class="entry-title" itemprop="headline"><abbr itemprop="headline">',the_title(),'</abbr></h1>';

              echo '<div class="date updated">';
                  echo '<p>';
                      //記事の更新日時を表示
                      echo '<span itemprop="datePublished" content="',the_time('Y-n-jTg:i'),'">',the_time('Y年n月j日 g:i a'),'</span>';
                      //著者情報
                      echo '<a href="',get_author_posts_url( get_the_author_meta( 'ID' ) ), '" title="',get_the_author(),'" class="vcard author"><span class="fn" itemprop="author" itemscope itemtype="http://schema.org/Person">',get_the_author(),'</span></a>';
                  echo '</p>';
              echo '</div>';
          }else{
              echo '<h1 class="entry-title">';
              echo '<a href="',the_permalink(),'" rel="bookmark">',the_title(),'</a>';
              echo '</h1>';
          }
      echo '</header>';
      
      if( is_single() ){
        echo '<div class="entry-content">';
          include "share_buttons.php";
              the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'twentytwelve' ) );
               wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'twentytwelve' ), 'after' => '</div>' ) );

							get_template_part('wifiarticle');

							/**
               * 広告挿入
               */
              echo '<span class="sponsor">スポンサーリンク</span>';
              if(!is_NoAdsense())	get_template_part('ad_300_250_2');

          echo '</div>';//entry-content

          echo '<footer class="entry-meta tag_box">';
          the_tags('<p>タグ : ',' ','</p>');
          echo '</footer>';

          /**
           * WP Social Bookmarking Lightのプラグインを使って，SNSのマークをそれぞれ挿入
          */
          include "share_buttons.php";
          
          /**
           * popinのレコメンドが挿入される
           * divのほうでjsを読み込んでくれている
           */
					echo '<div id="_popIn_recommend"></div>';
?>
<!-- popinタグ（レコメンド） -->
<script type="text/javascript">
    (function() {
        var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.charset = "utf-8"; pa.async = true;

        pa.src = window.location.protocol + "//api.popin.cc/searchbox/traicy.js";

        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(pa, s);

    })(); 

</script>
<!-- popinタグ（レコメンド） -->
<?php
      }else{
          echo '<div class="entry-summary" itemprop="headline">';
              the_excerpt();
          echo '</div>';
      }
    ?>
    <?php //}}} ?>
  <?php endif; //AMP分岐終わり-------------------------------------?>
</article><!-- #post -->

<?php
	echo '</article>';
?>

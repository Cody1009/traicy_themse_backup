<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: feed-facebook ( facebook instant articles ) */
?>
<?xml version="1.0" encoding="utf-8" ?>

<rss version="2.0"
xmlns:gnf="http://assets.gunosy.com/media/gnf"
xmlns:content="http://purl.org/rss/1.0/modules/content/"
xmlns:dc="http://purl.org/dc/elements/1.1/"
xmlns:media="http://search.yahoo.com/mrss/">

<channel>
  <title>トラベルメディア「Traicy」</title>
  <link>http://www.traicy.com/</link>
  <description>航空・鉄道・ホテルなど旅行情報をお送りするメディア。</description>
  <language>ja</language>
  <lastBuildDate><?php echo mysql2date("Y-m-d\TH:i:s+0900", get_lastpostmodified(), false); ?></lastBuildDate>

<?php query_posts("posts_per_page=10"); ?>
<?php while (have_posts()) : the_post(); ?>
  <item>
    <title><?php the_title_rss() ?></title>
    <link><?php the_permalink_rss() ?></link>
    <content:encoded>
    <![CDATA[<?php echo format_html(get_the_content()); ?>]]>
    </content:encoded>
    <guid><?php echo $post->ID; ?></guid>
    <description><?php the_excerpt(); ?></description>
    <pubDate><?php echo get_post_time("Y-m-d\TH:i:s+0900"); ?></pubDate>
    <author><?php echo get_the_author(); ?></author>
  </item>
<?php endwhile ; ?>
</channel>
</rss>

<?php
function format_html($html_text) {
  /*
    feed配信に適したhtmlに変換する
   */
  // iframeタグはおそらくyoutubeの埋め込みなので<figure class="op-interactive">で囲んであげる
  $html_text = preg_replace("/(<iframe.*?\/iframe>)/", "<figure class='op-interactive'>\\0</figure>", $html_text);
  
  // imgタグは<figure>で囲んであげる
  $html_text = preg_replace("/(<img.*?>)/", "<figure>\\0</figure>", $html_text);

  // strongタグは使えないっぽいので消す
  $html_text = preg_replace("/<\/?strong>/", "", $html_text);

  // 行頭が"<"または空白で始まらない行(記事の文章部)をpタグで囲んで返す
  $html_text =  preg_replace("/^([^<\s].*)$/m", "<p>\\0</p>", $html_text);

  // 広告を配置する
  $banner_ad = '<figure class="op-ad"><iframe width="320" height="50" style="border:0; margin:0;" src="https://www.facebook.com/adnw_request?placement=307853719600479_307853796267138&adtype=banner320x50"></iframe></figure>';
  $rectangle_ad = '<figure class="op-ad"><iframe width="300" height="250" style="border:0; margin:0;" src="https://www.facebook.com/adnw_request?placement=307853719600479_307853796267138&adtype=banner300x250"></iframe></figure>';

  $html_text .=  $rectangle_ad;

  // アナリティクスコードを付ける
  $analytics_code = "<figure class='op-tracker'><iframe><script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o), m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m) })(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create', 'UA-24526458-3', 'auto'); ga('send', 'pageview');</script></iframe></figure>'";

  $html_text .=  $analytics_code;

  return $html_text;
}
?>

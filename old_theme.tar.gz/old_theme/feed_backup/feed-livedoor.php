<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: feed-livedoor */
?>
<?xml version="1.0" encoding="utf-8" ?>
<rss version="2.0"
xmlns:ldnfeed="http://news.livedoor.com/ldnfeed/1.1/"
xmlns:atom="http://www.w3.org/2005/Atom">
<channel>
<language>ja</language>
<title>トラベルメディア「Traicy」</title>
<link>http://www.traicy.com/</link>
<description>航空・鉄道・ホテルなど旅行情報をお送りするメディア。</description>
<?php query_posts("posts_per_page=100"); ?>
<?php while (have_posts()) : the_post(); ?>
<item>
  <guid><?php echo $post->ID; ?></guid>
  <title><?php the_title_rss() ?></title>
  <link><?php the_permalink_rss() ?></link>
  <pubDate><?php echo get_post_time("D, d M Y H:i:s +0900"); ?></pubDate>
  <lastpubDate><?php echo get_post_modified_time("D, d M Y H:i:s +0900", false, $post->ID, false); ?></lastpubDate>
  <status><?php echo atom_get_post_status($post->ID); ?></status>
  <description>
    <![CDATA[<?php echo atom_get_content(get_the_content()); ?>]]>
  </description>
  <category>IT 経済</category>
</item>
<?php endwhile ; ?>
</channel>
</rss>

<?php
#---------------------------------------------
# 投稿のステータスを返す
# @param int $post_id 投稿ID
# @return int ステータス（新規=1 更新=2 削除=0）
#---------------------------------------------
function atom_get_post_status($post_id) {
  $status = get_post_status( $post_id );

  # 現在も公開されている記事であれば公開日時と
  # 最終更新日時を比較して新規か更新かを判断
  if ($status == 'publish') {
    $published_at     = new DateTime(get_post_time('c', false, $post->ID, false));
    $last_modified_at = new DateTime(get_post_modified_time('c', false, $post->ID, false));
    
    # 投稿時間と最終更新時間が1秒違ったりする謎のケースがあるので、
    # 一分だけ余裕を持たせておく
    if ($last_modified_at <= $published_at->modify('+1 minutes')){
      return 1; # 新規
    } else {
      return 2; # 更新
    }
  } else {
    return 0; # 削除
  }
}

#---------------------------------------------
# 投稿の本文をfeed配信に適したhtmlに変換する
# @param string $html_text 本文html
# @return string 変換された本文html
#---------------------------------------------
function atom_get_content($html_text) {

  //行頭が"<"または空白で始まらない行を<p>で囲む
  $html_text = preg_replace("/^([^<\s].*)$/m", "<p>\\0</p>", $html_text);

  // strongタグは使えないのでemタグに変換する
  $html_text = preg_replace("/strong>/m", "em>", $html_text);

  return $html_text;
}
?>

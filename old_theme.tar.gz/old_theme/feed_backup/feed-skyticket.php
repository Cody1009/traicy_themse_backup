<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: feed-gunosy */
?>
<?xml version="1.0" encoding="utf-8" ?>

<rss version="2.0"
xmlns:content="http://purl.org/rss/1.0/modules/content/"
xmlns:dc="http://purl.org/dc/elements/1.1/"
xmlns:media="http://search.yahoo.com/mrss/">

<channel>
  <title>トラベルメディア「Traicy」</title>
  <link>http://www.traicy.com/</link>
  <description>航空・鉄道・ホテルなど旅行情報をお送りするメディア。</description>
  <image>
    <url>http://www.traicy.com/images/logo_280x280.png</url>
    <title>トラベルメディア「Traicy」</title>
    <link>http://www.traicy.com/</link>
  </image>
  <language>ja</language>
  <copyright>Copyright 2016 TRAICY JAPAN</copyright>

  <?php query_posts("posts_per_page=30"); ?>
  <?php while (have_posts()) : the_post(); ?>
  <item>
    <title><?php the_title_rss() ?></title>
    <link><?php the_permalink_rss() ?></link>
    <guid><?php echo $post->ID; ?></guid>
    <description><?php the_excerpt(); ?></description>
    <content:encoded>
    <![CDATA[<?php echo atom_get_content(get_the_content()); ?>]]>
    </content:encoded>
    <pubDate><?php echo get_post_time("D, d M Y H:i:s +0900"); ?></pubDate>
    <author><?php echo get_the_author(); ?></author>
    <enclosure url="<?php echo the_post_thumbnail_url('large'); ?>" caption="記事サムネイル"/>
  </item>
  <?php endwhile ; ?>
</channel>
</rss>

<?php
function atom_get_revision($post_id) {
	$defaults = array(
		'post_parent' => $post_id,
		'post_type'   => 'revision',
		'numberposts' => -1,
		'post_status' => 'any'
	);

    $child = count(get_children($defaults));
    return $child ? $child-1 : 0;
}

function atom_get_status($post_id) {
  $child_count = atom_get_revision($post_id);
  if ($child_count >= 0){
    return 'active';
  } else {
    return 'deleted';
  }
}

function atom_get_content($html_text) {
  /*
    feed配信に適したhtmlに変換する
   */

  //行頭が"<"または空白で始まらない行を<p>で囲んで返す
  return preg_replace("/^([^<\s].*)$/m", "<p>\\0</p>", $html_text);
}

function get_tag_name($tag){
  return $tag->name;
}

function atom_post_tags($post_tags){
  /*
    投稿についているタグをカンマ区切りで連結して返す
   */
  if ( $post_tags ) {
    $tag_names = array_map("get_tag_name", $post_tags);

    # タグ（キーワード）は10個まで
    $tag_names = array_splice($tag_names, 0, 10);

    return join(',', $tag_names);
  } else {
    return "";
  }
}
?>

<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: feed-starthome */
?>
<?xml version="1.0" encoding="utf-8" ?>

<rss version="2.0" 
xmlns:content="http://purl.org/rss/1.0/modules/content/"
xmlns:dc="http://purl.org/dc/elements/1.1/"
xmlns:media="http://search.yahoo.com/mrss/"
xmlns:snf="http://www.smartnews.be/snf">

<channel>
	<title>トラベルメディア「Traicy」</title>
	<link>http://www.traicy.com/</link>
	<description>旅行、航空、鉄道など趣味や経済ニュース</description>
	<pubDate><?php echo mysql2date('Y-m-d\TH:i:s+09:00', get_lastpostmodified(), false); ?></pubDate>
	<language>ja</language>
	<copyright>Copyright 2016 TRAICY</copyright>
	<ttl>1</ttl>
	<snf:logo><url>http://i0.wp.com/www.traicy.com/wp-content/uploads/2016/03/traicy_logo.png</url></snf:logo>
	<image>
		<url>http://www.traicy.com/images/logo.gif</url>
		<title>トラベルメディア「Traicy」</title>
		<link>http://www.traicy.com/</link>
	</image>
<?php $more = 1 ?>
<?php query_posts("posts_per_page=30&amp;category_name=''"); ?>
<?php while (have_posts()) : the_post(); ?>
	<item>
		<title><?php the_title_rss() ?></title>
		<link><?php the_permalink_rss() ?></link>
		<guid><?php the_permalink_rss() ?></guid>
		<description><![CDATA[<?php the_excerpt(); ?>]]></description>
		<pubDate><?php echo get_post_time('r', true); ?> GMT</pubDate>
		<content:encoded>
			<![CDATA[<?php echo atom_get_content(get_the_content()); ?>]]>
		</content:encoded>
		<category>travel,economy,hobby,aviation,domestic,railway,column</category>
		<dc:creator><![CDATA[<?php echo get_the_author(); ?>]]></dc:creator>
		<dc:language>ja</dc:language>
		<media:thumbnail url="<?php 
$post_thumbnail_id = get_post_thumbnail_id( get_the_ID() );
$image = wp_get_attachment_image_src( $post_thumbnail_id, 'post-thumbnail' );
if ( $image ) {
  list($src, $width, $height) = $image;
  echo esc_attr( $src );
}?>"></media:thumbnail>
<media:status>active</media:status>

<snf:relatedLink title="航空会社の安全性評価　最低ランクは10社　インドネシアが大半" thumbnail ="http://i2.wp.com/www.traicy.com/wp-content/uploads/2016/01/Airlineratings.jpg" link="http://www.traicy.com/20160107-AirlineRatings" />
<snf:relatedLink title="最も安全な航空会社、トップはカンタス航空　日本の2社もランクイン" thumbnail ="http://i2.wp.com/www.traicy.com/wp-content/uploads/2015/10/ba5ed99517.jpg" link="http://www.traicy.com/20160106-AirlineRatings" />
<snf:relatedLink title="伊丹空港と羽田空港、2015年の定時発着率でトップ　OAG調査" thumbnail ="http://i2.wp.com/www.traicy.com/wp-content/uploads/2016/01/oag.jpg" link="http://www.traicy.com/20160108-OAG1" />

		<snf:advertisement>
				<snf:adcontent>
<![CDATA[
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- SmartNews-Traicy -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-3121993718200907"
     data-ad-slot="6141967534"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
]]>
				</snf:adcontent>
		</snf:advertisement>

	</item>
	<?php endwhile ; ?>
</channel>
</rss>

<?php
function atom_get_revision($post_id) {
	$defaults = array( 
		'post_parent' => $post_id,
		'post_type'   => 'revision', 
		'numberposts' => -1,
		'post_status' => 'any'
	);
	$child = count(get_children($defaults)) - 1;
	if ($child == NULL || $child == -1) $child = 0;
	return $child;
}

function atom_get_status($post_id) {
	$child_count = atom_get_revision($post_id);
	$status = 'updated';
	if ($child_count == 0) $status = 'new';
	return $status;
}

function atom_get_category() {
	$category = get_the_category();
	$ret = '';
	for($i = 0; $i < count($category); $i++){
		$ret .= '<category term ="tag" label="' . $category[$i]->name . '" />
		';
		if($i == 3) break;
	}
	return $ret;
}

function atom_get_content($html_text) {
  /*
    feed配信に適したhtmlに変換する
   */

  //行頭が"<"または空白で始まらない行を<p>で囲んで返す
  return preg_replace("/^([^<\s].*)$/m", "<p>\\0</p>", $html_text);
}

function atom_get_summary($summary) {
	$ret = strip_tags($summary);
	return $ret;
}

?>

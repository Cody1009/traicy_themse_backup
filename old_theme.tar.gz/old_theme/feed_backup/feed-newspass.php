<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: feed-newspass (smartnewsと同じ) */
?>
<?xml version="1.0" encoding="utf-8" ?>

<rss version="2.0" 
xmlns:content="http://purl.org/rss/1.0/modules/content/"
xmlns:dc="http://purl.org/dc/elements/1.1/"
xmlns:media="http://search.yahoo.com/mrss/"
xmlns:snf="http://www.smartnews.be/snf">

<channel>
    <title>トラベルメディア「Traicy」</title>
    <link>http://www.traicy.com/</link>
    <description>航空・鉄道・ホテルなど旅行情報をお送りするメディア。</description>
    <pubDate><?php echo mysql2date("D, d M Y H:i:s +0900", get_lastpostmodified(), false); ?></pubDate>
    <language>ja</language>
    <copyright>Copyright 2016 TRAICY</copyright>
    <snf:logo><url>http://www.traicy.com/images/logo.gif</url></snf:logo>
    <image>
        <url>http://www.traicy.com/images/logo.gif</url>
        <title>トラベルメディア「Traicy」</title>
        <link>http://www.traicy.com/</link>
    </image>
<?php query_posts("posts_per_page=30"); ?>
<?php while (have_posts()) : the_post(); ?>
    <item>
        <title><?php the_title_rss() ?></title>
        <link><?php the_permalink_rss() ?></link>
        <guid><?php the_permalink_rss() ?></guid>
        <description><?php the_excerpt(); ?></description>
        <pubDate><?php echo get_post_time("D, d M Y H:i:s +0900"); ?></pubDate>
        <content:encoded>
            <![CDATA[<?php echo atom_get_content(get_the_content()); ?>]]>
        </content:encoded>
        <category><?php echo atom_post_tags(get_the_tags()); ?></category>
        <dc:creator><?php echo get_the_author(); ?></dc:creator>
        <dc:language>ja</dc:language>
        <media:thumbnail url="<?php echo the_post_thumbnail_url('large'); ?>"></media:thumbnail>
        <media:status><?php echo atom_get_status($post->ID); ?></media:status>
        <snf:advertisement>
        <snf:adcontent>
        <![CDATA[
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- SmartNews-Traicy -->
        <ins class="adsbygoogle"
             style="display:inline-block;width:300px;height:250px"
             data-ad-client="ca-pub-3121993718200907"
             data-ad-slot="6141967534"></ins>
        <script>
          (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
        ]]>
        </snf:adcontent>
        </snf:advertisement>

        <snf:analytics>
        <![CDATA[
        <script>
          (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
              m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

                  ga('create', 'UA-24526458-3', 'auto');
                  ga('send', 'pageview');

        </script>
        ]]>
      </snf:analytics>
    </item>
    <?php endwhile ; ?>
</channel>
</rss>

<?php
function atom_get_revision($post_id) {
	$defaults = array( 
		'post_parent' => $post_id,
		'post_type'   => 'revision', 
		'numberposts' => -1,
		'post_status' => 'any'
	);
	$child = count(get_children($defaults)) - 1;
	if ($child == NULL || $child == -1) $child = 0;
	return $child;
}

function atom_get_status($post_id) {
  $child_count = atom_get_revision($post_id);
  if ($child_count >= 0){
    return 'active';
  } else {
    return 'deleted';
  }
}

function atom_get_content($html_text) {
  /*
    feed配信に適したhtmlに変換する
   */

  //行頭が"<"または空白で始まらない行を<p>で囲んで返す
  return preg_replace("/^([^<\s].*)$/m", "<p>\\0</p>", $html_text);
}

function get_tag_name($tag){
  return $tag->name;
}

function atom_post_tags($post_tags){
  /*
    投稿についているタグをカンマ区切りで連結して返す
   */
  if ( $post_tags ) {
    $tag_names = array_map("get_tag_name", $post_tags);
    return join(',', $tag_names);
  } else {
    return "";
  }
}
?>

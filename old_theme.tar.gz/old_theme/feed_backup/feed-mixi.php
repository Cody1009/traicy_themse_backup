<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: rss-mixi */
?>
<?php echo '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?'.'>' ?>

<feed xmlns="http://www.w3.org/2005/Atom" xml:lang="ja">
<?php $more = 1 ?>
<?php query_posts("posts_per_page=30&amp;category_name=''"); ?>
<?php while (have_posts()) : the_post(); ?>

<item>
	<id><?php echo get_post_time('Ymd'); ?>_<?php echo $post->ID ?></id>
	<status><?php echo atom_get_status($post->ID) ?></status>
  <revision><?php echo atom_get_revision($post->ID) ?></revision>
	<created_at><?php echo get_post_time('Y-m-d\TH:i:s+09:00'); ?></created_at>
	<updated_at><?php echo get_post_modified_time('Y-m-d\TH:i:s+09:00'); ?></updated_at>
	<category>経済</category>
	<title type="main"><![CDATA[<?php the_title_rss() ?>]]></title>
	<description type="main">
		<![CDATA[<?php echo remove_invalid_tags(get_the_content()) ?>]]>
	</description>
  <image>
    <original><?php echo get_thumbnail_image($post->ID)?></original>
  </image>
</item>
	<?php endwhile ; ?>
</feed>

<?php
function atom_get_revision($post_id){
	$args = array(
		'post_parent' => $post_id,
		'post_type'   => 'revision', 
		'numberposts' => -1,
		'post_status' => 'publish'
	);
  $num_child = count(get_children($args));

  // revisionは記事が作成された時点で1なのでカウントアップして返す
  return $num_child == NULL ? 1 : $num_child + 1;
}

function atom_get_status($post_id) {
	$child_count = atom_get_revision($post_id);

  if ($child_count == 1){
    return 'create';
  } else {
    return 'update';
  }
}

function atom_get_category() {
	$category = get_the_category();
	$ret = '';
	for($i = 0; $i < count($category); $i++){
		$ret .= '<category term ="tag" label="' . $category[$i]->name . '" />
		';
		if($i == 3) break;
	}
	return $ret;
}

function atom_get_related($post_id) {
	$yarpp_related = yarpp_get_related(NULL, $post_id);
	$ret = '';
	for($i = 0; $i < count($yarpp_related); $i++){
		$ret .= '
		<related type="main"><title><![CDATA["' . htmlspecialchars(get_the_title($yarpp_related[$i]->ID)) . '"]]></title><url>"' . get_permalink($yarpp_related[$i]->ID) . '"</url></related> />';
		if ($i == 2) break;
	}
	return $ret . "\n";
}

function atom_get_attachment($post_id) {
	$args = array(
		'post_type' => 'attachment',
		'posts_per_page' => 100,
		'numberposts' => null,
		'post_status' => 'inherit',
		'post_parent' => $post_id
	);
	$attachments = get_posts($args);
	$ret = '';
	for($i = 0; $i < count($attachments); $i++){
		$ret .= '
		<link rel="related" href="' . $attachments[$i]->guid . '" title="' . htmlspecialchars($attachments[$i]->post_excerpt) . '" />';
		if ($i == 99) break;
	}
	return $ret . "\n";
}

// - 使用不可能なタグを削除する
// - サムネイル画像（最初の一枚目の画像）のimgタグを削除する
function remove_invalid_tags($content) {
  // [$invalid_tag_regexの生成]
  // $valid_tags = array('p', 'br', 'strong', 'a', 'h2', 'h2', 'h3',
  //                     'blockquote', 'ul', 'ol', 'li', 'iframe');
  // $invalid_tag_regex = "";
  // foreach($valid_tags as $tag) $invalid_tag_regex .= "(?!\/?$tag)";
  
  # htmlタグの中から使用不可能なものを削除
  $invalid_tag_regex = '(?!\/?p)(?!\/?br)(?!\/?strong)(?!\/?a)(?!\/?h2)(?!\/?h3)(?!\/?h4)(?!\/?h5)(?!\/?blockquote)(?!\/?ul)(?!\/?ol)(?!\/?li)(?!\/?img)(?!\/?iframe)';
  $pattern = '{' ."<$invalid_tag_regex(\"[^\"]*\"|'[^']*'|[^'\">])*>" . '}';
  $content = preg_replace($pattern, '', $content); 

  # サムネイル画像を削除 (aタグで囲まれている場合はaも削除)
  $pattern = '{' . '<a.*?><img.*?>.*?<\/a>|<img.*?>' . '}';
  $content = preg_replace($pattern, '', $content, 1);

  return $content;
}

function atom_get_summary($summary) {
	$ret = strip_tags($summary);
	return $ret;
}

// 記事のサムネイル画像を取得する
function get_thumbnail_image($post_id) {
  $post_thumbnail_id = get_post_thumbnail_id( $post_id );
  $image = wp_get_attachment_image_src( $post_thumbnail_id, 'post-thumbnail' );
  if ( $image ) {
    list($src, $width, $height) = $image;
    return esc_attr( $src );
  } else {
    return '';
  }
}
?>

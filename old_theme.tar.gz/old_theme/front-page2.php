<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * For example, it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */

get_header(); ?>

<div id="primary" class="site-content">
<div id="content" role="main">	

<!-- トップページ表示 -->
<ul class="hide_u600">
<div class="clearfix box_wrap">
<a href="<?php the_permalink(); ?>">
	<?php setup_postdata(get_posts(array('posts_per_page' => 1))); ?>
	<div class="box_left_img"><?php the_post_thumbnail(); ?></div>
	<div class="box_right">
		<h2><?php the_title(); ?></h2>
		<?php the_excerpt(); ?>
	</div>
	<?php wp_reset_postdata(); ?>
</a>
</div>
</ul>
<!-- トップページ表示 鎌田寛　20160621-->
<!-- 600px以下の場合表示 -->
<ul>
<div class="clearfix box_wrap_sp hide_o600">
<a href="<?php the_permalink(); ?>">
	<?php setup_postdata(get_posts(array('posts_per_page' => 1))); ?>
	<div class="box_left_img_sp"><?php the_post_thumbnail(); ?></div>
	<div class="box_left_title_sp">
		<h2><?php the_title(); ?></h2>
	</div>
	<?php wp_reset_postdata(); ?>
</a>
</div>
</ul>
<!-- 600px以下の場合表示 -->
	
<!-- ad st -->
<center>
<?php get_template_part('ad_300_250_2'); ?>
</center>
<!-- ad en -->

<!--カテゴリ表示-->
<div id="topic"><!-- 新着記事 st -->
	<ul class="contents half_c sub_content">
		<div id="tabnavi">
			<ul>
				<li><a href="#tab01">新着</a></li>
				<li><a href="#tab02">航空</a></li>
				<li><a href="#tab03">セール</a></li>
				<li><a href="#tab04">運航</a></li>
				<li><a href="#tab05">乗り物</a></li>
				<li><a href="#tab06">ホテル</a></li>
				<li><a href="#tab07">リリース</a></li>
			</ul>
		</div>
		<div id="tabcontent">
			<div id="tab01"><!--{{{-->
				<?php
				query_posts('posts_per_page=10&ignore_sticky_posts=0');
				$termId = get_category_by_slug('information')->term_id;
				$catArchiveUrl = get_term_link($termId , 'category'); //カテゴリーアーカイブのURL
				?>
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post();	?>
				<a href="<?php the_permalink(); ?>" class="new-entry-title clearfix">
				<li class="line2c">
				<div class="new-entry">
				  <div class="new-entry-thumb left">
				  	<?php if ( has_post_thumbnail()): // サムネイルを持っているときの処理 ?>
				  	  <?php the_post_thumbnail('thumbnail'); ?>
				  	<?php else: // サムネイルを持っていないときの処理 ?>
				  	  <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/dummy_600_400.jpg" alt="NO IMAGE" title="NO IMAGE"/>
				  	<?php endif; ?>
				  </div><!-- /.new-entry-thumb -->
				  <div class="new-entry-content right title">
						<?php the_title(); ?>
						<div class="line_up">
							<div class="date">
									<p><?php the_time('\'y n/j G:i'); ?></p>
							</div><!-- .date -->

							<?php if (!is_null($cat)) : ?>
							<div class="delicious">
							<span><ul>
								<?php foreach((get_the_category()) as $cat){
									echo '<li>' . $cat->cat_name . '</li> '; } ?>
							</ul></span>
							</div>
							<?php endif; ?>
						</div>
					</div><!-- /.new-entry-content -->
				</a>
				</div><!-- /.new-entry -->
				</li><!-- /.line2c -->
				<?php endwhile; endif; ?>
				<?php wp_reset_query(); ?>
				<div class='wp-pagenavi'>
					<a class="page smaller" href="<?php bloginfo('url'); ?>/newarticle/page/1">1</a>
					<a class="page smaller" href="<?php bloginfo('url'); ?>/newarticle/page/2">2</a>
					<a class="page smaller" href="<?php bloginfo('url'); ?>/newarticle/page/3">3</a>
					<a class="page smaller" href="<?php bloginfo('url'); ?>/newarticle/page/4">4</a>
					<a class="page smaller" href="<?php bloginfo('url'); ?>/newarticle/page/5">5</a>
					<a class="page smaller" href="<?php bloginfo('url'); ?>/newarticle/page/6">6</a>
					<a class="nextpostslink" rel="next" href="<?php bloginfo('url'); ?>/newarticle/page/1">次のページ »</a>
				</div>
			</div><!--}}}-->
			<div id="tab02"><?php cat_post_list( array( 'posts_per_page' => 10, 'cat' => array(1433,-82,-1844) ) ); ?></div>
			<div id="tab03"><?php cat_post_list( array( 'posts_per_page' => 10, 'cat' => 82 ) ); ?></div>
			<div id="tab04"><?php cat_post_list( array( 'posts_per_page' => 10, 'cat' => 1844 ) ); ?></div>
			<div id="tab05"><?php cat_post_list( array( 'posts_per_page' => 10, 'cat' => array(8481,243,606,8961) ) ); ?></div>
			<div id="tab06"><?php cat_post_list( array( 'posts_per_page' => 10, 'cat' => array(213,242,272,1399) ) ); ?></div>
			<div id="tab07">
				<?php
					include_once( ABSPATH . WPINC . '/feed.php' );
					$rss = fetch_feed('http://release.traicy.com/?feed=rss');
					if ( !is_wp_error( $rss ) ) {
						$rss->set_cache_duration(3600); /* cache間隔の設定 */
						$rss->init();
						$maxitems = $rss->get_item_quantity( 10 );
						$rss_items = $rss->get_items( 0, $maxitems );
					}
				?>
				<?php if ( !empty( $maxitems ) ) : ?>
				<ul>
					<?php foreach ( $rss_items as $item ) : ?>
					<a href="<?php echo $item->get_permalink(); ?>" class="new-entry-title clearfix">
					<li class="line2c"><!--{{{-->
					<div class="new-entry">
						<div class="new-entry-thumb left">
							<?php
								$first_img = '';
								// 記事中の1枚目の画像を取得
								if ( preg_match( '/<img.+?src=[\'"]([^\'"]+?)[\'"].*?>/msi', $item->get_content(), $matches ) ) {
									$first_img = $matches[1];
								}
							?>
							<?php if ( !empty( $first_img ) ) : ?>
								<img src="<?php echo esc_attr( $first_img ); ?>" alt="" />
							<?php else: ?>
				  	  	<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/dummy_600_400.jpg" alt="NO IMAGE" title="NO IMAGE"/>
							<?php endif; ?>
						</div>
						<div class="new-entry-content right title">
							<?php echo $item->get_title(); ?>
							<div class="line_up">
								<div class="date">
									<p>
										<?php echo $item->get_date('\'y n/j G:i'); ?>
									</p>
								</div><!-- .date -->
							</div>
						</div>
					</div>
					</li>
					</a><!--}}}-->
					<?php endforeach; ?>
				</ul>
				<?php endif; ?>
			</div>
		</div>

	</ul>
</div>








<!--広告-->
<center>
<div class="sub_ad hide_u600">
<script type='text/javascript'>
	<!--//<![CDATA[
   	document.MAX_ct0 ='';
   	var m3_u = (location.protocol=='https:'?'https://cas.criteo.com/delivery/ajs.php?':'http://cas.criteo.com/delivery/ajs.php?');
   	var m3_r = Math.floor(Math.random()*99999999999);
   	document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
   	document.write ("zoneid=421707");document.write("&amp;nodis=1");
   	document.write ('&amp;cb=' + m3_r);
   	if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
   	document.write (document.charset ? '&amp;charset='+document.charset : (document.characterSet ? '&amp;charset='+document.characterSet : ''));
   	document.write ("&amp;loc=" + escape(window.location).substring(0,1600));
   	if (document.context) document.write ("&context=" + escape(document.context));
   	if ((typeof(document.MAX_ct0) != 'undefined') && (document.MAX_ct0.substring(0,4) == 'http')) {
   		document.write ("&amp;ct0=" + escape(document.MAX_ct0));
   	}
   	if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
   	var publisherurl = "%%SITE%%";
   	var macro = "%%SI" + "TE%%";
   	if (publisherurl !== macro) document.write ("&amp;publisherurl="+publisherurl);
   	document.write ("'></scr"+"ipt>");
//]]>--></script>
</div>
</center>
<!--広告-->


<!-- ad st -->
<!-- 600px以下の場合表示 -->
<div class="hide_o600 sp_ad">
<center>
<!--広告-->
<script async defer src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Traicy-New-Top-ArticleFooter-left -->
<ins class="adsbygoogle"
	style="display:inline-block;width:300px;height:250px"
	data-ad-client="ca-pub-3121993718200907"
	data-ad-slot="7111125932"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</center>
</div>

<!-- 600px以下の場合表示 -->
<!-- ad en -->

<!-- ランキング -->
<span class="hide_o600">
<?php //if (wp_is_mobile()){
get_template_part('ranking');
//} ?>
</span>
<!-- ランキング -->

<!-- facebookのいいねボタン　facebook.phpにソースコードを移動 20160621 鎌田寛-->

<div id="topic" class="hide_u600">
<h2 class="main_category">お知らせ</h2>
<ul class="contents information">
<?php
	$termId = get_category_by_slug('information')->term_id;
	$catArchiveUrl = get_term_link($termId , 'category'); //カテゴリーアーカイブのURL
	$args = array(
		'numberposts' => 5,
		'cat'=> $termId
	);
	$i=0;
	$customPosts = get_posts($args);
	if($customPosts) : foreach($customPosts as $post) : setup_postdata( $post ); ?>
	<a href="<?php the_permalink(); ?>">
	<li class="active">
	<div class="title4" ><?php the_title(); ?>(<?php echo get_the_date(); ?>)</div>
	</li>
	</a>
	<?php $i++;?>
	<?php endforeach; ?>
	<?php else : //記事が無い場合 ?>
		<li><p>記事はまだありません。</p></li>
	<?php $i++;?>
	<?php endif;?>
	<?php
		while($i < 4){
			echo "<li><div class='title' >　</div></li>";
			$i++;
		}
	?>
</ul>
</div>

</div><!-- #content -->
</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>

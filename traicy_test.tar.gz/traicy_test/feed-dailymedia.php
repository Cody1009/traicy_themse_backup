<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: feed-dailymedia */
?>
<?php echo '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?'.'>' ?>

<rss version="2.0" xmlns:gnf="http://assets.gunosy.com/media/gnf" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:media="http://search.yahoo.com/mrss/"  >

<channel>
	<title>トラベルメディア「Traicy」</title>
	<link>http://www.traicy.com/</link>
	<language>ja</language>
	<description>旅行情報ニュースサイト</description>
	<copyright>Copyright 2016 TRAICY JAPAN</copyright>
	<lastBuildDate><?php echo mysql2date('r', get_lastpostmodified(), false); ?></lastBuildDate>
	<image>
		<url>http://i0.wp.com/www.traicy.com/wp-content/uploads/2016/06/logo_traicy400400.jpeg?fit=400%2C400</url>
		<title>トラベルメディア「Traicy」</title>
		<link>http://www.traicy.com/</link>
	</image>

<?php $more = 1 ?>
<?php query_posts("posts_per_page=30&amp;category_name=''"); ?>
<?php while (have_posts()) : the_post(); ?>
	<item>
		<title><?php the_title_rss() ?></title>
		<link><?php the_permalink_rss() ?></link>
		<guid><?php echo $post->ID ?></guid>
		<gnf:category>entertainment</gnf:category>
		<pubDate><?php echo get_post_time('r'); ?></pubDate>
		<gnf:modified><?php echo get_post_modified_time('r'); ?></gnf:modified>
		<description>
			<![CDATA[<?php echo atom_get_content(get_the_content()) ?>]]>
		</description>
		<content:encoded>
			<![CDATA[<?php echo atom_get_content(get_the_content()) ?>]]>
		</content:encoded>
		<media:status state="active" />
		<gnf:relatedLink title="航空会社の安全性評価　最低ランクは10社　インドネシアが大半" link="http://www.traicy.com/20160107-AirlineRatings" />
		<gnf:relatedLink title="最も安全な航空会社、トップはカンタス航空　日本の2社もランクイン" link="http://www.traicy.com/20160106-AirlineRatings" />
		<gnf:relatedLink title="伊丹空港と羽田空港、2015年の定時発着率でトップ　OAG調査" link="http://www.traicy.com/20160108-OAG1" />
		<gnf:analytics><![CDATA[
		<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

		ga('create', 'UA-24526458-4', 'auto');
		ga('send', 'pageview');
		</script>
		]]></gnf:analytics>
	</item>
	<?php endwhile ; ?>
</channel>
</rss>

<?php
function atom_get_revision($post_id) {
	$defaults = array( 
		'post_parent' => $post_id,
		'post_type'   => 'revision', 
		'numberposts' => -1,
		'post_status' => 'any'
	);
	$child = count(get_children($defaults)) - 1;
	if ($child == NULL || $child == -1) $child = 0;
	return $child;
}

function atom_get_status($post_id) {
	$child_count = atom_get_revision($post_id);
	$status = 'updated';
	if ($child_count == 0) $status = 'new';
	return $status;
}

function atom_get_category() {
	$category = get_the_category();
	$ret = '';
	for($i = 0; $i < count($category); $i++){
		$ret .= '<category term ="tag" label="' . $category[$i]->name . '" />
		';
		if($i == 3) break;
	}
	return $ret;
}

function atom_get_content($ret) {
	$ret = preg_replace("/\[caption.+\/caption\][(\n|\s)]+/", '', $ret);
	$ret = preg_replace("/\[caption.+\/caption\]/", '', $ret);
	$ret = preg_replace("/<br clear=\"all\" \/>[(\n|\s)]+/", '', $ret);

	$ret = nl2br($ret);
	return $ret;
}

function atom_get_summary($summary) {
	$ret = strip_tags($summary);
	return $ret;
}

?>
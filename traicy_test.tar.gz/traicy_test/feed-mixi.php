<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: rss-mixi */
?>
<?php echo '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?'.'>' ?>
<feed xmlns="http://www.w3.org/2005/Atom" xml:lang="ja">

<?php $more = 1 ?>
<?php query_posts("posts_per_page=30&amp;category_name=''"); ?>
<?php while (have_posts()) : the_post(); ?>

<item>
		<id><?php echo get_post_time('Ymd'); ?>-<?php echo $post->ID ?></id>
		<status><?php echo atom_get_status($post->ID) ?></status>
		<revision>1</revision>
		<created_at><?php echo get_post_time('Y-m-d\TH:i:s+09:00'); ?></created_at>
		<updated_at><?php echo get_post_modified_time('Y-m-d\TH:i:s+09:00'); ?></updated_at>
		<category>経済</category>
		<title type="main"><![CDATA[<?php the_title_rss() ?>]]></title>
		<description type="main">
			<![CDATA[<?php echo atom_get_content(get_the_content()) ?>]]>
		</description>
		<image><original><?php the_post_thumbnail('full'); ?></original></image>
		<related type="main">
		<title>最も安全な航空会社、トップはカンタス航空　日本の2社もランクイン</title>
		<url>http://www.traicy.com/20160106-AirlineRatings</url>
		</related>
		<related type="main">
		<title>航空会社の安全性評価　最低ランクは10社　インドネシアが大半</title>
		<url>http://www.traicy.com/20160107-AirlineRatings</url>
		</related>
		<related type="main">
		<title>隣の席が肥満で怪我？　オーストラリアの男性が航空会社を提訴</title>
		<url>http://www.traicy.com/archives/8949993-2.html</url>
		</related>
		<related type="mobile">
		<title>最も安全な航空会社、トップはカンタス航空　日本の2社もランクイン</title>
		<url>http://www.traicy.com/20160106-AirlineRatings</url>
		</related>
</item>
	<?php endwhile ; ?>
</feed>

<?php
function atom_get_revision($post_id) {
	$defaults = array( 
		'post_parent' => $post_id,
		'post_type'   => 'revision', 
		'numberposts' => -1,
		'post_status' => 'any'
	);
	$child = count(get_children($defaults)) - 1;
	if ($child == NULL || $child == -1) $child = 0;
	return $child;
}

function atom_get_status($post_id) {
	$child_count = atom_get_revision($post_id);
	$status = 'update';
	if ($child_count == 0) $status = 'create';
	return $status;
}

function atom_get_category() {
	$category = get_the_category();
	$ret = '';
	for($i = 0; $i < count($category); $i++){
		$ret .= '<category term ="tag" label="' . $category[$i]->name . '" />
		';
		if($i == 3) break;
	}
	return $ret;
}

function atom_get_related($post_id) {
	$yarpp_related = yarpp_get_related(NULL, $post_id);
	$ret = '';
	for($i = 0; $i < count($yarpp_related); $i++){
		$ret .= '
		<title><![CDATA["' . htmlspecialchars(get_the_title($yarpp_related[$i]->ID)) . '"]]></title><url>"' . get_permalink($yarpp_related[$i]->ID) . '"</url> />';
		if ($i == 2) break;
	}
	return $ret . "\n";
}

function atom_get_attachment($post_id) {
	$args = array(
		'post_type' => 'attachment',
		'posts_per_page' => 100,
		'numberposts' => null,
		'post_status' => 'inherit',
		'post_parent' => $post_id
	);
	$attachments = get_posts($args);
	$ret = '';
	for($i = 0; $i < count($attachments); $i++){
		$ret .= '
		<link rel="related" href="' . $attachments[$i]->guid . '" title="' . htmlspecialchars($attachments[$i]->post_excerpt) . '" />';
		if ($i == 99) break;
	}
	return $ret . "\n";
}

function atom_get_content($ret) {
	$ret = preg_replace("/\[caption.+\/caption\][(\n|\s)]+/", '', $ret);
	$ret = preg_replace("/\[caption.+\/caption\]/", '', $ret);
	$ret = preg_replace("/<br clear=\"all\" \/>[(\n|\s)]+/", '', $ret);
	$ret = nl2br($ret);
    $ret = preg_replace("/<img[^>]+\>/i", "[画像]", $ret); 
	$pattern = '/(<a href=["\'])(.*?)(["\'](?:\s?.*?)?>)/i';
    $ret = preg_replace($pattern, '<a href="$2">', $ret); 
	return $ret;
}

function atom_get_summary($summary) {
	$ret = strip_tags($summary);
	return $ret;
}

?>
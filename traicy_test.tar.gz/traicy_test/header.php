<?php
//print '<pre>';print_r(get_option( 'rewrite_rules' ));print '</pre>';
/**
 * The Header template for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
<!DOCTYPE html>

   <!-- AMPチェック 参考：　https://q-az.net/amp-wordpress-without-plugin/　-->
  <?php
  $myAmp = false;
  $string = $post->post_content;
  if($_GET['amp'] === '1' && strpos($string,'<script>') === false && is_single()){
      $myAmp = true;
  }
  ?>

  <?php if($myAmp): ?>
  <html>
      <head>
  <?php else: ?>
    <!--[if IE 7]>
    <html class="ie ie7" <?php language_attributes(); ?>>
    <![endif]-->
    <!--[if IE 8]>
    <html class="ie ie8" <?php language_attributes(); ?>>
    <![endif]-->
    <!--[if !(IE 7) & !(IE 8)]>
    <html <?php language_attributes(); ?>>
    <!<![endif]-->
  <html lang="ja">
      <head prefix="og: http://ogp.me/ns# article: http://ogp.me/ns/article#">
  <?php endif; ?>

<!-- AMP metaタグ 参考：　https://q-az.net/amp-wordpress-without-plugin/　-->
<meta charset="<?php bloginfo( 'charset' ); ?>" />

<!-- icon用cssの読み込み -->
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/icomoon/icomoon.css">


<?php if($myAmp): ?>
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
<?php else: ?>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<?php endif; ?>

<!-- AMP canonical 参考：　https://q-az.net/amp-wordpress-without-plugin/　-->
<?php if($myAmp): ?>
<?php
    $canonical_url = get_permalink();
?>
    <link rel="canonical" href="<?php echo $canonical_url; ?>" />
<?php endif; ?>

<title><?php wp_title( '|', true, 'right' ); ?></title>

<!-- AMP linkタグ 参考：　https://q-az.net/amp-wordpress-without-plugin/　-->
<?php if(!$myAmp): ?>
<script async defer src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<?php if( is_single() ): ?>
    <?php if( have_posts() ): ?>
        <?php while( have_posts() ): the_post(); ?>
            <link rel="alternate" hreflang="ja" href="<?php the_permalink(); ?>">
        <?php endwhile; ?>
    <?php endif; ?>
<?php elseif( is_home() ): ?>
    <link rel="alternate" hreflang="ja" href="<?php echo home_url(); ?>">
<?php endif; ?>

<link rel="alternate" type="application/rss+xml" title="トラベルメディア
「Traicy（トライシー）」 &raquo; フィード"
href="http://newsformat.jp/hd/traicy/http://www.traicy.com/feed" />

<?php // Loads HTML5 JavaScript file to add support for HTML5 elements in older IE versions. ?>
<!--[if lt IE 9]>
<script async defer src="<?php echo get_stylesheet_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->
<?php endif; ?><!-- AMP linkタグ -->

<!-- AMP AMPで使用可能なscriptタグ 参考：　https://q-az.net/amp-wordpress-without-plugin/　-->
<?php if($myAmp): ?>
    <style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
    <script async src="https://cdn.ampproject.org/v0.js"></script>
<?php endif; ?>

<?php wp_head(); ?>

<!-- カテゴリ一覧 -->
<script type="text/javascript">
jQuery(function($){
	$('#tabcontent > div').hide();

	$('#tabnavi a').click(function () {
		$('#tabcontent > div').hide().filter(this.hash).fadeIn();
		
		$('#tabnavi a').removeClass('active');
		$(this).addClass('active');
		
				return false;
			}).filter(':eq(0)').click();
});
</script>



<!-- メニュースクロール静止 st -->
<?php if(!$myAmp): ?>
<script type="text/javascript">
jQuery(function($) {

  var nav = $('.PC_nav'),
      offset = nav.offset();

  $(window).scroll(function () {
    if($(window).scrollTop() > offset.top) {
      nav.addClass('fixed');
    } else {
      nav.removeClass('fixed');
    }
  });
});
</script>
<?php endif; ?>
<!-- メニュースクロール静止 en -->

<!-- AMP Json -->
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "NewsArticle",
  "mainEntityOfPage":{
    "@type":"WebPage",
    "@id":"<?php the_permalink(); ?>"
  },
  "headline": "<?php bloginfo('description'); ?>",
  "image": {
    "@type": "ImageObject",
    "url": "<?php the_post_thumbnail(); ?>",
    "height": 600,
    "width": 400
  },
  "datePublished": "2015-12-15T06:00:00+09:00",
  "dateModified": "2015-02-15T06:00:00+09:00",
  "author": {
    "@type": "Person",
    "name": "<?php the_author(); ?>"
  },
   "publisher": {
    "@type": "Organization",
    "name": "<?php wp_title(); ?>",
    "logo": {
      "@type": "ImageObject",
      "url": "<?php get_stylesheet_directory_uri() ;?>/images/logo.gif",
      "width": 273,
      "height": 147
    }
  },
  "description": "<?php bloginfo('description'); ?>"
}
</script>
<!-- AMP Json -->

<!-- AMP boilerplate -->
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
<!-- AMP boilerplate -->

<!-- AMP ライブラリ -->
<script async src="https://cdn.ampproject.org/v0.js"></script>
<!-- AMP ライブラリ -->

<!-- AMP クローラー対策 -->
<link rel="amphtml" href="<?php echo esc_url( home_url( '/' ) );?>/url/to/amp-version.html">
<!-- AMP クローラー対策 -->

</head>

<body <?php body_class(); ?>>

  <!-- fbいいねBOX用 st -->
  <div id="fb-root"></div>
  <script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/ja_JP/sdk.js#xfbml=1&version=v2.4&appId=113076798842836";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));</script>
  <!-- fbいいねBOX用 en -->

    <div id="header" class="hide_u600">
			<div class="header_text">
				<a href="/"><div>traicy</div></a>
				<a href="http://www.hotelers.jp/"><div>Hotelers</div></a>
				<a href="http://www.guesthousetoday.jp/"><div>GuesthouseToday</div></a>
				<a href="http://www.extrain.info/"><div>EX-TRAIN</div></a>
				<a href="http://www.traicy.com.tw/"><div>Traicy Taiwan</div></a>
			</div>
			<div class="social-icon">
				<a class="side-twitter" href="https://twitter.com/traicycom" target="_blank"><span class="icon-twitter"></span></a>
				<a class="side-facebook" href="https://www.facebook.com/traicycom" target="_blank"><span class="icon-facebook"></span></a>
				<a class="side-rss" href="http://newsformat.jp/hd/traicy/http://www.traicy.com/feed" target="_blank"><span class="icon-rss"></span></a>
				<a class="side-feedly" href="http://cloud.feedly.com/#subscription%2Ffeed%2Fhttp%3A%2F%2Fnewsformat.jp%2Fhd%2Ftraicy%2Fhttp%3A%2F%2Fwww.traicy.com%2Ffeed" target="_blank"><span class="icon-feedly"></span></a>
				<a class="side-google-plus" href="https://plus.google.com/116492855879080319968/" target="_blank"><span class="icon-google-plus"></span></a>
				<a class="side-line" href="http://line.me/ti/p/%40traicy" target="_blank"><span class="icon-line"></span></a>
			</div>
  		<a href=""><div class="clear"></div></a>
  	</div><!-- #header -->


    <div itemscope itemtype="http://schema.org/Article" id="page" class="hfeed site">



    <header id="masthead" class="site-header" role="banner">

    <div class="title_bar">

    <nav id="site-navigation" class="hide_o600 main-navigation fixed" role="navigation">
      <span class="left"><a href="<?php echo esc_url( home_url( '/' ) );?>"><img class="header_logo" src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif"></a></span>
        <span class="sp_right">
          <button class="menu-toggle"><?php _e( 'Menu', 'twentytwelve' ); ?></button>
          <a class="assistive-text" href="#content" title="<?php esc_attr_e( 'Skip to content', 'twentytwelve' ); ?>"><?php _e( 'Skip to content', 'twentytwelve' ); ?></a>
          <?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
        </span><!-- .sp_right -->
    </nav><!-- #site-navigation -->

    <a href="<?php echo esc_url( home_url( '/' ) );?>"><img class="header_logo hide_u600" src="<?php get_stylesheet_directory_uri() ;?>/images/logo.gif"></a>　

			<!--/* 広告 */-->
      <?php if(!is_NoAdsense()) { ?>
      <center>
      <!-- 擬似広告に置き換えるために以下の一行を追加 20160619 @sada -->

      <script async defer src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
      <!-- Traicy-20151007 -->
      <ins class="adsbygoogle my_adslot"
           style="display:block"
           data-ad-client="ca-pub-3121993718200907"
           data-ad-slot="6481590338"
           data-ad-region="Traicy-header"
           data-ad-format="auto"></ins>
      <script>
      (adsbygoogle = window.adsbygoogle || []).push({});
      </script>
    </center>
    <?php } ?>
    <!--/* 広告 */-->
    
    <span class="clear"></span>

    </div><!-- .title_bar -->
      <script>
        function oritatami(id){
          obj=(document.all)?document.all(id):((document.getElementById)?document.getElementById(id):null);
          if(obj) obj.style.display=(obj.style.display=="none")?"block":"none";
        }
      </script>

    <nav id="site-navigation" class="main-navigation hide_u600 PC_nav" role="navigation">
        <span class="sp_right">
          <button class="menu-toggle"><?php _e( 'Menu', 'twentytwelve' ); ?></button>
          <a class="assistive-text" href="#content" title="<?php esc_attr_e( 'Skip to content', 'twentytwelve' ); ?>"><?php _e( 'Skip to content', 'twentytwelve' ); ?></a>
          <?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
        </span><!-- .sp_right -->
    </nav><!-- #site-navigation -->

  </header><!-- #masthead -->

	<div id="main" class="wrapper">

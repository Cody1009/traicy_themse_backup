<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
		<div class="featured-post">
			<?php _e( 'Featured post', 'twentytwelve' ); ?>
		</div>
		<?php endif; ?>
		<header class="entry-header">
			<a href="<?php the_permalink(); ?>" rel="bookmark">
			<?php if ( ! post_password_required() && ! is_attachment() && ! is_single()) :
				the_post_thumbnail();
			endif; ?>
		</a>
		
		

			<?php if ( is_single() ) : ?>
			<div class="delicious">
				<?php the_category(''); ?>
			</div>
			<h1 itemprop="name" class="entry-title" itemprop="headline"><abbr itemprop='headline'><?php the_title(); ?></abbr></h1>
			<?php if (is_syndicated()) :
				$corpArr = get_post_meta($post->ID, 'corp', false);
			?>
			  <div class="corp" ><?=$corpArr[0]?></div>
			<?php endif; ?>
			<div class="date updated">
			<p>
				<span itemprop="datePublished" content="<?php the_time('Y-n-jTg:i'); ?>">
				<?php the_time('Y年n月j日 g:i a'); ?>
				</span>
			<?php echo '<a href="' . get_author_posts_url( get_the_author_meta( 'ID' ) ) . '" title="' . get_the_author() . '" class="vcard author">'.'<span class="fn" itemprop="author" itemscope itemtype="http://schema.org/Person">' . get_the_author() . '</span>' . '</a>'; ?>
			</p>
			</div><!-- .date -->
			<?php else : ?>
			<h1 class="entry-title">
				<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
			</h1>
			<?php endif; // is_single() ?>
			<?php if ( comments_open() ) : ?>
				<div class="comments-link">
					<?php comments_popup_link( '<span class="leave-reply">' . __( 'Leave a reply', 'twentytwelve' ) . '</span>', __( '1 Reply', 'twentytwelve' ), __( '% Replies', 'twentytwelve' ) ); ?>
				</div><!-- .comments-link -->
			<?php endif; // comments_open() ?>
		</header><!-- .entry-header -->

		<?php wp_sb_light() ?>

		<?php if ( is_single() ) :  ?>
			<div class="entry-content">
				<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'twentytwelve' ) ); ?>
				<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'twentytwelve' ), 'after' => '</div>' ) ); ?>
						
				<!-- 著者情報 -->
				<?php
				// If a user has filled out their description, show a bio on their entries.
				if ( get_the_author_meta( 'description' ) ) : ?>
				<div class="author-info">
					<div class="author-avatar">
						<?php
						/**
						 * Filter the author bio avatar size.
						 *
						 * @since Twenty Twelve 1.0
						 *
						 * @param int $size The height and width of the avatar in pixels.
						 */
						$author_bio_avatar_size = apply_filters( 'twentytwelve_author_bio_avatar_size', 120 );
						echo get_avatar( get_the_author_meta( 'user_email' ), $author_bio_avatar_size );
						?>
					</div><!-- .author-avatar -->
					<div class="author-description">
						<h2><?php printf( __( '%s', 'twentytwelve' ), get_the_author() ); ?></h2>
						<p><?php the_author_meta( 'description' ); ?></p>
					</div><!-- .author-description	-->
				</div><!-- .author-info -->
				<?php endif; ?>
				<!-- 著者情報 -->

				<?php if(!is_NoAdsense()) { ?>
				<!-- ad st -->
				<?php get_template_part('ad_300_250_2');?>
				<!-- ad en -->

				<?php } ?>

				<div class="share_box">

			</div><!-- .entry-content -->
		<?php else : ?>
			<div class="entry-summary" itemprop="headline">
				<?php the_excerpt(); ?>
			</div><!-- .entry-summary -->
		<?php endif; ?>

		<footer class="entry-meta tag_box">
			<?php the_tags('<p>タグ : ',' ','</p>'); ?>
		</footer><!-- .entry-meta -->


		<?php if ( is_single() ) : // Only display Excerpts for Search ?>
		<!-- 共有BOX st -->
		<center class="share_box">
			<a href="http://www.facebook.com/share.php?u=<?php echo the_permalink();?>&amp;t=<?php echo get_the_title($post); ?>" onclick="window.open(this.href, 'FBwindow', 'width=650, height=380, menubar=no, toolbar=no, scrollbars=yes'); return false;">
				<div class="btn_share_fb">Facebookでシェア</div>
			</a>
			<a href="http://twitter.com/share?url=<?php echo the_permalink();?>&amp;text=<?php echo get_the_title($post); ?>&amp;via=traicycom&amp;data-related='traicycom,hotelersjp:ホテル情報専門メディア'&amp;lang=ja" onclick="window.open(this.href, 'FBwindow', 'width=650, height=380, menubar=no, toolbar=no, scrollbars=yes'); return false;">
				<div class="btn_share_tw">Twitterでシェア</div>
			</a>
			<div class="clear"/>
		</center>
		<!-- 共有BOX en -->

		<!-- popin レコメンド -->
		<div id="_popIn_recommend"></div>
		<!-- popin レコメンド -->

	<?php endif ?>


	</article><!-- #post -->


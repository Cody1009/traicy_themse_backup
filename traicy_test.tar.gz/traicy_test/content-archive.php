<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>

<ul>
<?php

query_posts('posts_per_page=6&ignore_sticky_posts=0');

$termId = get_category_by_slug('information')->term_id;
$catArchiveUrl = get_term_link($termId , 'category'); //カテゴリーアーカイブのURL

?>



<li class="line2c">
	<a href="<?php the_permalink(); ?>" class="new-entry-title clearfix">

<div class="new-entry">

	<div class="new-entry-thumb left">
	<?php if ( has_post_thumbnail()): // サムネイルを持っているときの処理 ?>
		<?php the_post_thumbnail('thumbnail'); ?>
	<?php else: // サムネイルを持っていないときの処理 ?>
		<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/dummy_600_400.jpg" alt="NO IMAGE" title="NO IMAGE"/>
	<?php endif; ?>
	</div><!-- /.new-entry-thumb -->

	<div class="new-entry-content right title">

		<p class="atitle">
		<?php the_title(); ?>
		</p>
		
		<span class="hide_u600">
		<p>
		<?php the_excerpt(); ?>
		</p>
		</span>
		
		<div class="line_up">
		<div class="date">
		<p><?php the_time('Y年n月j日 g:i a'); ?></p>
		</div><!-- .date -->
		</div>





	</div><!-- /.new-entry-content -->

</div><!-- /.new-entry -->
</a>
</li><!-- /.line2c -->




<?php wp_reset_query(); ?>
</ul>

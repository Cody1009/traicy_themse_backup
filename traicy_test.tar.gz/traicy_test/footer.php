<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>
	</div><!-- #main .wrapper -->
	<footer id="colophon" role="contentinfo">

		<!-- AD 広告 -->
		<?php if(!is_NoAdsense()) { ?>

		<center>
		<script async defer src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
		<ins class="adsbygoogle my_adslot"
				 style="display:block"
				 data-ad-client="ca-pub-3121993718200907"
				 data-ad-slot="6481590338"
				 data-ad-region="Traicy-footer"
				 data-ad-format="auto"></ins>
		<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
		</script>
		</center>
		<?php } ?>
		<!-- AD 広告 -->


		<div class="site-info">
			<div class="about_traicy">
					<center>
						<span class="parent">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/ma.gif">
					<ul class="about">
						<li><a href="http://www.traicy.com/information">お知らせ</a></li>
						<li><a href="http://www.traicy.com/kiyaku">利用規約</a></li>
						<li><a href="http://www.traicy.com/article_provide">配信先一覧</a></li>
						<li><a href="http://www.traicy.com/writer">ライター一覧</a></li>
						<li><a href="http://www.traicy.com/ad">広告掲載</a></li>
						<li><a href="http://www.traicy.com/traicybloggernetwork">ブロガーネットワーク登録</a></li>
						<li><a href="http://www.traicy.com/mailmag">メルマガ登録</a></li>
						<!-- <li><a href="https://pushsan.com/applications/XTI572f731ee99a2">プッシュ通知（Android）</a></li> -->
						<li><a href="http://line.me/ti/p/%40traicy">LINE登録</a></li>
						<li><a href="http://www.traicy.com/wanted">採用情報</a></li>
						<li><a href="http://www.traicy.com/about#company">運営会社情報</a></li>
						<li><a href="http://www.traicy.com/contact">お問い合わせ</a></li>
					</ul>
					</center>
			</div><!-- .about_traicy -->
		</div><!-- .site-info -->


	</footer><!-- #colophon -->
</div><!-- #page -->

<!-- popinタグ（レコメンド） -->
<script type="text/javascript">

	(function() {

			var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.charset = "utf-8"; pa.async = true;

			pa.src = window.location.protocol + "//api.popin.cc/searchbox/traicy.js";

			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(pa, s);

	})();

</script>
<!-- popinタグ（レコメンド） -->

<?php wp_footer(); ?>

</body>
</html>

<?php header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true) ?>
<?php
/* Template Name: feed-gunosy */
?>
<?php echo '<?xml version="1.0" encoding="'.get_option('blog_charset').'"?'.'>' ?>

<rss version="2.0" xmlns:ldnfeed="http://news.livedoor.com/ldnfeed/1.1/">

<channel>
	<title>トラベルメディア「Traicy」</title>
	<link>http://www.traicy.com/</link>
	<description>サイトの説明</description>
	<language>ja</language>
	<copyright>Copyright 2014 Mobilemedia Production</copyright>
	<lastBuildDate><?php echo mysql2date('Y-m-d\TH:i:s+09:00', get_lastpostmodified(), false); ?></lastBuildDate>
	<enclosure><url></url></enclosure>

<?php $more = 1 ?>
<?php query_posts("posts_per_page=30&amp;category_name=''"); ?>
<?php while (have_posts()) : the_post(); ?>
	<item>
		<title><?php the_title_rss() ?></title>
		<content type="<?php html_type_rss(); ?>">
			<![CDATA[<?php echo atom_get_content(get_the_content()) ?>]]>
		</content>
		<link><?php the_permalink_rss() ?></link>
		<pubDate><?php echo get_post_time('Y-m-d\TH:i:s+09:00'); ?></pubDate>
		<lastBuildDate><?php echo get_post_modified_time('Y-m-d\TH:i:s+09:00'); ?></lastBuildDate>
		<ldnfeed:rel><ldnfeed:rel_link>http://www.traicy.com/20160530-HD</ldnfeed:rel_link><ldnfeed:rel_subject>エア・ドゥ、特別塗装機「ベア・ドゥ北海道 JET」就航　7月29日から</ldnfeed:rel_subject></ldnfeed:rel>
		<ldnfeed:rel><ldnfeed:rel_link>http://www.traicy.com/20160602-kddi</ldnfeed:rel_link><ldnfeed:rel_subject>KDDI、海外32ヶ国・地域で日本のデータ定額利用可能に　24時間980円で</ldnfeed:rel_subject></ldnfeed:rel>
		<ldnfeed:rel><ldnfeed:rel_link>http://www.traicy.com/20160516-fukabori</ldnfeed:rel_link><ldnfeed:rel_subject>総額24万円で”ヨーロッパ4回＋ドバイへ無料ビジネスクラス”のウラ技【橋賀秀紀のフカボリ！】</ldnfeed:rel_subject></ldnfeed:rel>
	</item>
	<?php endwhile ; ?>
</channel>
</rss>

<?php
function atom_get_revision($post_id) {
	$defaults = array( 
		'post_parent' => $post_id,
		'post_type'   => 'revision', 
		'numberposts' => -1,
		'post_status' => 'any'
	);
	$child = count(get_children($defaults)) - 1;
	if ($child == NULL || $child == -1) $child = 0;
	return $child;
}

function atom_get_status($post_id) {
	$child_count = atom_get_revision($post_id);
	$status = 'updated';
	if ($child_count == 0) $status = 'new';
	return $status;
}

function atom_get_category() {
	$category = get_the_category();
	$ret = '';
	for($i = 0; $i < count($category); $i++){
		$ret .= '<category term ="tag" label="' . $category[$i]->name . '" />
		';
		if($i == 3) break;
	}
	return $ret;
}

function atom_get_related($post_id) {
	$yarpp_related = yarpp_get_related(NULL, $post_id);
	$ret = '';
	for($i = 0; $i < count($yarpp_related); $i++){
		$ret .= '

<ldnfeed:rel><ldnfeed:rel_link>' . get_permalink($yarpp_related[$i]->ID) . '</ldnfeed:rel_link><ldnfeed:rel_subject>' . htmlspecialchars(get_the_title($yarpp_related[$i]->ID)) . '" </ldnfeed:rel_subject></ldnfeed:rel>';
		if ($i == 2) break;
	}
	return $ret;
}

function atom_get_content($ret) {
	$ret = preg_replace("/\[caption.+\/caption\][(\n|\s)]+/", '', $ret);
	$ret = preg_replace("/\[caption.+\/caption\]/", '', $ret);
	$ret = preg_replace("/<br clear=\"all\" \/>[(\n|\s)]+/", '', $ret);
	$ret = nl2br($ret);
	return $ret;
}

function atom_get_summary($summary) {
	$ret = strip_tags($summary);
	return $ret;
}

?>
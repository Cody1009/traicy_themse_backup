<!-- 600px以上1020px以下の場合表示 -->
<div class="hide_o1020">
  <center>
    <!--広告-->
    <script async defer src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Traicy-New-Top-ArticleFooter-left -->
    <ins class="adsbygoogle"
         style="display:inline-block;width:300px;height:250px"
         data-ad-client="ca-pub-3121993718200907"
         data-ad-slot="7111125932"
         data-ad-region="{value}"
         data-ad-region = "sq_1";>
         </ins>
    <script>
    (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
  </center>
</div>
<!-- 600px以上1020px以下の場合表示 -->

<!-- 1020px以上の場合表示 -->
<table class="hide_u1020">
<tr>
<td>
  <center style="margin-right:0px;">
    <!--広告-->
  <script async defer src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <!-- Traicy-New-Top-ArticleFooter-left -->
  <ins class="adsbygoogle"
       style="display:inline-block;width:300px;height:250px"
       data-ad-client="ca-pub-3121993718200907"
       data-ad-slot="7111125932"
       data-ad-region = "sq_2";>
     </ins>
  <script>
  (adsbygoogle = window.adsbygoogle || []).push({});
  </script>

  </center>
</td>
<td>
  <center style="margin-left:10px;">
    <!--広告-->
    <!--/* VASCO Javascript Tag v */-->
    <script type='text/javascript'><!--//<![CDATA[
       document.MAX_ct0 ='INSERT_CLICKURL_HERE';

    if (location.protocol=='https:') {
    } else {
       var m3_u = 'http://vsc.send.microad.jp/delivery/ajs.php';
       var m3_r = Math.floor(Math.random()*99999999999);
       if (!document.MAX_used) document.MAX_used = ',';
       document.write ("<scr"+"ipt type='text/javascript' src='"+m3_u);
       document.write ("?zoneid=8003&amp;charset=UTF-8");
       document.write ('&amp;snr=2&amp;cb=' + m3_r);
       if (document.MAX_used != ',') document.write ("&amp;exclude=" + document.MAX_used);
       document.write ('&amp;charset=UTF-8');
       document.write ("&amp;loc=" + encodeURIComponent(window.location));
       if (document.referrer) document.write ("&amp;referer=" + encodeURIComponent(document.referrer));
       if (document.context) document.write ("&context=" + encodeURIComponent(document.context));
       if ((typeof(document.MAX_ct0) != 'undefined') && (document.MAX_ct0.substring(0,4) == 'http')) {
           document.write ("&amp;ct0=" + encodeURIComponent(document.MAX_ct0));
       }
       if (document.mmm_fo) document.write ("&amp;mmm_fo=1");
       document.write ("'><\/scr"+"ipt>");
    }

//]] > </script><noscript><a href='http://vsc.send.microad.jp/delivery/ck.php?n=a1ffaf53&amp;cb=INSERT_RANDOM_NUMBER_HERE' target='_blank'><img src='http://vsc.send.microad.jp/delivery/avw.php?zoneid=8003&amp;charset=UTF-8&amp;cb=INSERT_RANDOM_NUMBER_HERE&amp;n=a1ffaf53&amp;ct0=INSERT_CLICKURL_HERE&amp;snr=2' border='0' alt='' /></a></noscript>
  </center>
</td>
</tr>
</table>
<!-- 1020px以上の場合表示 -->
